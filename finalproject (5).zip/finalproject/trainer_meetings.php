<?php
// trainer_meetings.php
session_start();
include 'navbar.php';
include_once 'db_connection.php';
$con = OpenCon();

if (!isset($_SESSION['logged_in_user']) || !isset($_SESSION['is_trainer']) || $_SESSION['is_trainer'] != 1) {
    header("Location: login.php");
    exit();
}

$username = $_SESSION['logged_in_user'];

// get user id
$u_res = mysqli_query($con, "SELECT id FROM users WHERE username = '$username'");
$u_row = mysqli_fetch_assoc($u_res);
if (!$u_row) { echo "<div class='info-message'>User not found.</div>"; exit(); }
$user_id = (int)$u_row['id'];

// get trainer id
$t_res = mysqli_query($con, "SELECT id FROM trainers WHERE user_id = $user_id");
$t_row = mysqli_fetch_assoc($t_res);
if (!$t_row) { echo "<div class='info-message'>Not a trainer.</div>"; exit(); }
$trainer_id = (int)$t_row['id'];


mysqli_query($con, "
  UPDATE trainer_orders
  SET meeting_day = NULL,
      meeting_time = NULL
  WHERE trainer_id = $trainer_id
    AND program_end_date IS NOT NULL
    AND program_end_date < CURDATE()
    AND (meeting_day IS NOT NULL OR meeting_time IS NOT NULL)
");

/* ---------------- handle sending link email (unchanged) ---------------- */
$flash = '';
if (isset($_POST['send_link'])) {
    $order_id = (int)$_POST['order_id'];
    $meeting_link = trim($_POST['meeting_link']);

    $o_res = mysqli_query($con, "SELECT user_id, meeting_day, meeting_time FROM trainer_orders WHERE id = $order_id AND trainer_id = $trainer_id");
    $order = mysqli_fetch_assoc($o_res);

    if ($order) {
        $client_id = (int)$order['user_id'];
        $c_res = mysqli_query($con, "SELECT firstname, lastname, email FROM users WHERE id = $client_id");
        $client = mysqli_fetch_assoc($c_res);

        if ($client && !empty($client['email'])) {
            $to = $client['email'];
            $subject = "Your training call link";
            $msg  = "<p>Hello " . htmlspecialchars($client['firstname'] . ' ' . $client['lastname']) . ",</p>";
            $msg .= "<p>Here is the link for your weekly training call:</p>";
            $msg .= "<p><a href=\"" . htmlspecialchars($meeting_link) . "\">" . htmlspecialchars($meeting_link) . "</a></p>";
            $msg .= "<p>Scheduled on <b>" . htmlspecialchars($order['meeting_day']) . " at " . htmlspecialchars($order['meeting_time']) . "</b>.</p>";
            $msg .= "<p>See you then!</p>";

            $headers  = "From: no-reply@yourapp.local\r\n";
            $headers .= "MIME-Version: 1.0\r\n";
            $headers .= "Content-type: text/html; charset=UTF-8\r\n";

            if (mail($to, $subject, $msg, $headers)) {
                $flash = "<div class='info-message' style='color:green;'>Link sent to {$client['email']}.</div>";
            } else {
                $flash = "<div class='info-message' style='color:red;'>Could not send email (check local mail setup).</div>";
            }
        } else {
            $flash = "<div class='info-message' style='color:red;'>Client email not found.</div>";
        }
    } else {
        $flash = "<div class='info-message' style='color:red;'>Invalid order.</div>";
    }
}

// today's meetings
$today = date('l');


$meetings = [];
$m_res = mysqli_query($con, "
    SELECT id, user_id, meeting_time
    FROM trainer_orders
    WHERE trainer_id = $trainer_id
      AND meeting_day = '$today'
      AND meeting_time IS NOT NULL
      AND (program_end_date IS NULL OR program_end_date >= CURDATE())
    ORDER BY meeting_time ASC
");
if ($m_res) {
    while ($row = mysqli_fetch_assoc($m_res)) {
        $cid = (int)$row['user_id'];
        $c_res = mysqli_query($con, "SELECT firstname, lastname FROM users WHERE id = $cid");
        $client = mysqli_fetch_assoc($c_res);

        $meetings[] = [
            'order_id'    => (int)$row['id'],
            'time'        => $row['meeting_time'],
            'client_name' => $client ? ($client['firstname'] . ' ' . $client['lastname']) : 'Client'
        ];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Today's Meetings</title>
<style>
body { font-family: Arial, sans-serif; margin:0; padding:0; background: url('images/back3.jpg') center/cover fixed no-repeat; color: #f5f6f8; }
.container { max-width: 1000px; margin: 40px auto; background: rgba(0,0,0,.55); backdrop-filter: blur(8px); -webkit-backdrop-filter: blur(8px); border-radius: 16px; box-shadow: 0 10px 30px rgba(0,0,0,.35); padding: 28px; border: 1px solid rgba(255,255,255,.18); }
h2 { margin: 0 0 16px; color: #ffe08a; text-align: center; }
.sub { color: #ddd; margin-bottom: 20px; text-align: center; }
.table { width: 100%; border-collapse: collapse; color: #fff; }
.table th, .table td { border-bottom: 1px solid rgba(255,255,255,.15); padding: 10px 8px; text-align: left; vertical-align: middle; }
.table th { background: rgba(255,255,255,.08); color: #ffd86e; font-weight: bold; }
.meeting-input { width: 100%; padding: 8px; border: 1px solid rgba(255,255,255,.2); border-radius: 6px; background: rgba(255,255,255,.08); color: #fff; }
.btn { background: #ff8c3a; color: #fff; border: none; border-radius: 8px; padding: 8px 14px; font-size: 0.95em; cursor: pointer; text-decoration: none; display: inline-block; box-shadow: 0 4px 12px rgba(0,0,0,.3); transition: background .2s; }
.btn:hover { background: #e77a2f; }
.actions { display: flex; flex-direction: column; gap: 8px; }
.small { font-size: 0.9em; color: #ddd; }
.info-message { text-align: center; color: #ffe08a; background: rgba(255,255,255,.08); border: 1px solid rgba(255,255,255,.25); border-radius: 10px; padding: 11px; margin-bottom: 16px; }

</style>
</head>
<body>
<div class="container">
  <h2>Today's Meetings</h2>
  <div class="sub">Day: <b><?php echo htmlspecialchars($today); ?></b></div>
  <?php if (!empty($flash)) echo $flash; ?>

  <?php if (empty($meetings)): ?>
    <p class="small">No meetings scheduled for today.</p>
  <?php else: ?>
    <table class="table">
      <tr>
        <th style="width:100px;">Time</th>
        <th>Client</th>
        <th>Meeting Link</th>
        <th style="width:220px;">Actions</th>
      </tr>
      <?php foreach ($meetings as $m): ?>
        <tr>
          <td><?php echo htmlspecialchars($m['time']); ?></td>
          <td><?php echo htmlspecialchars($m['client_name']); ?></td>
          <td>
            <form method="post" style="display:flex; gap:8px; align-items:center;">
              <input type="hidden" name="order_id" value="<?php echo $m['order_id']; ?>">
              <input class="meeting-input" type="text" name="meeting_link" placeholder="Paste meeting URL...">
          </td>
          <td class="actions">
              <button class="btn" type="submit" name="send_link">Send Link</button>
              <a class="btn" href="trainer_view_program.php?order_id=<?php echo $m['order_id']; ?>">View / Edit Program</a>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
    </table>
  <?php endif; ?>
</div>
</body>
</html>
