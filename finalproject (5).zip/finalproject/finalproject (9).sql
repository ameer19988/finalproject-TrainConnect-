-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 11, 2025 at 03:49 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `finalproject`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories_new`
--

CREATE TABLE `categories_new` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `image` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `categories_new`
--

INSERT INTO `categories_new` (`id`, `name`, `image`) VALUES
(1, 'Nutritionist', 'images/nutr.jpg'),
(2, 'Boxing', 'images/boxing.jpg'),
(3, 'Calisthenics', 'images/calisthenics.jpg'),
(4, 'Yoga', 'images/yoga.png');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `trainer_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `sender` enum('user','trainer') NOT NULL,
  `message_text` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `reply_deadline` datetime DEFAULT NULL,
  `replied_at` datetime DEFAULT NULL,
  `points_given` tinyint(1) NOT NULL DEFAULT 0,
  `last_point_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `order_id`, `trainer_id`, `user_id`, `sender`, `message_text`, `created_at`, `reply_deadline`, `replied_at`, `points_given`, `last_point_date`) VALUES
(18, 12, 22, 1, 'user', 'Hi coach?', '2025-08-06 15:03:48', '2025-08-09 18:03:48', NULL, 0, '2025-08-10'),
(19, 15, 22, 1, 'user', 'hi i want some changes....', '2025-08-10 18:53:18', '2025-08-11 20:53:18', '2025-08-10 21:53:53', 0, NULL),
(20, 15, 22, 1, 'trainer', 'nnadnn andhjadlj', '2025-08-10 18:53:53', NULL, NULL, 0, NULL),
(21, 15, 22, 1, 'user', 'dvsdbfsb', '2025-08-10 19:41:33', '2025-08-11 21:41:33', NULL, 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `packages`
--

CREATE TABLE `packages` (
  `id` int(11) NOT NULL,
  `trainer_id` int(11) NOT NULL,
  `type` varchar(20) NOT NULL,
  `price` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `packages`
--

INSERT INTO `packages` (`id`, `trainer_id`, `type`, `price`) VALUES
(1, 1, 'regular', 150),
(2, 1, 'premium', 250),
(3, 2, 'regular', 130),
(4, 2, 'premium', 220),
(5, 3, 'regular', 120),
(6, 3, 'premium', 200),
(7, 22, 'regular', 200),
(8, 22, 'premium', 600),
(9, 4, 'regular', 100),
(10, 5, 'regular', 200),
(11, 21, 'regular', 150),
(12, 23, 'regular', 100),
(13, 27, 'regular', 250),
(14, 31, 'regular', 250),
(15, 35, 'regular', 250),
(16, 39, 'regular', 150),
(17, 6, 'regular', 200),
(18, 7, 'regular', 100),
(19, 8, 'regular', 200),
(20, 9, 'regular', 150),
(21, 10, 'regular', 150),
(22, 24, 'regular', 200),
(23, 28, 'regular', 250),
(24, 32, 'regular', 100),
(25, 36, 'regular', 150),
(26, 40, 'regular', 200),
(27, 11, 'regular', 200),
(28, 12, 'regular', 200),
(29, 13, 'regular', 200),
(30, 14, 'regular', 100),
(31, 15, 'regular', 100),
(32, 25, 'regular', 100),
(33, 29, 'regular', 150),
(34, 33, 'regular', 200),
(35, 37, 'regular', 100),
(36, 41, 'regular', 250),
(37, 16, 'regular', 200),
(38, 17, 'regular', 100),
(39, 18, 'regular', 150),
(40, 19, 'regular', 250),
(41, 20, 'regular', 100),
(42, 26, 'regular', 100),
(43, 30, 'regular', 250),
(44, 34, 'regular', 200),
(45, 38, 'regular', 250),
(72, 4, 'premium', 300),
(73, 5, 'premium', 600),
(74, 21, 'premium', 450),
(75, 23, 'premium', 300),
(76, 27, 'premium', 750),
(77, 31, 'premium', 750),
(78, 35, 'premium', 750),
(79, 39, 'premium', 450),
(80, 6, 'premium', 600),
(81, 7, 'premium', 300),
(82, 8, 'premium', 600),
(83, 9, 'premium', 450),
(84, 10, 'premium', 450),
(85, 24, 'premium', 600),
(86, 28, 'premium', 750),
(87, 32, 'premium', 300),
(88, 36, 'premium', 450),
(89, 40, 'premium', 600),
(90, 11, 'premium', 600),
(91, 12, 'premium', 600),
(92, 13, 'premium', 600),
(93, 14, 'premium', 300),
(94, 15, 'premium', 300),
(95, 25, 'premium', 300),
(96, 29, 'premium', 450),
(97, 33, 'premium', 600),
(98, 37, 'premium', 300),
(99, 41, 'premium', 750),
(100, 16, 'premium', 600),
(101, 17, 'premium', 300),
(102, 18, 'premium', 450),
(103, 19, 'premium', 750),
(104, 20, 'premium', 300),
(105, 26, 'premium', 300),
(106, 30, 'premium', 750),
(107, 34, 'premium', 600),
(108, 38, 'premium', 750);

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `trainer_id` int(11) NOT NULL,
  `review_text` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`id`, `user_id`, `trainer_id`, `review_text`, `created_at`) VALUES
(4, 1, 22, 'nkghshdbn anhdj', '2025-08-09 16:22:00');

-- --------------------------------------------------------

--
-- Table structure for table `trainers`
--

CREATE TABLE `trainers` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `experience` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `age` int(200) NOT NULL,
  `rating` int(11) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `delay_points` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `trainers`
--

INSERT INTO `trainers` (`id`, `name`, `experience`, `description`, `image`, `age`, `rating`, `category_id`, `user_id`, `delay_points`) VALUES
(1, 'Dana Green', '5', 'Certified nutritionist with 5 years experience and a passion for healthy living.', 'images/n2.jpg', 30, 5, 1, 4, 1),
(2, 'Michael Nutri', '7', 'Professional boxing coach with a focus on technique and competition.', 'images/nutr.jpg', 25, 3, 1, 5, 0),
(3, 'Sara Fit', '3', 'Dedicated to helping clients get stronger and leaner with calisthenics.', 'images/n6.jpg', 20, 5, 1, 6, 0),
(4, 'Tom Health', '6', 'Health coach for all levels, specializing in wellness and fitness.', 'images/n4.jpg', 30, 2, 1, 7, 8),
(5, 'Emily Wellness', '4', 'Certified nutritionist offering personalized meal plans and health coaching.', 'images/n1.jpg', 24, 4, 1, 8, 5),
(6, 'Alex Punch', '8', 'Professional boxing coach specializing in technique, power, and agility.', 'images/n2.jpg', 35, 5, 2, 9, 2),
(7, 'John Jab', '6', 'Professional boxing coach specializing in technique, power, and agility.', 'images/n2.jpg', 33, 3, 2, 10, 6),
(8, 'Lisa Hook', '4', 'Professional boxing coach specializing in technique, power, and agility.', 'images/n2.jpg', 26, 4, 2, 11, 4),
(9, 'Chris Uppercut', '7', 'Professional boxing coach specializing in technique, power, and agility.', 'images/n2.jpg', 0, 5, 2, 12, 2),
(10, 'Natalie Strike', '5', 'Professional boxing coach specializing in technique, power, and agility.', 'images/n2.jpg', 0, 2, 2, 13, 8),
(11, 'Ben Flow', '5', 'Calisthenics trainer helping clients improve strength and flexibility.', 'images/n2.jpg', 0, 3, 3, 14, 6),
(12, 'Anna Power', '3', 'Calisthenics trainer helping clients improve strength and flexibility.', 'images/n2.jpg', 0, 2, 3, 15, 8),
(13, 'David Bars', '6', 'Calisthenics trainer helping clients improve strength and flexibility.', 'images/n2.jpg', 0, 4, 3, 16, 3),
(14, 'Sophie Control', '4', 'Calisthenics trainer helping clients improve strength and flexibility.', 'images/n2.jpg', 0, 5, 3, 17, 0),
(15, 'Leo Moves', '7', 'Calisthenics trainer helping clients improve strength and flexibility.', 'images/n2.jpg', 0, 4, 3, 18, 3),
(16, 'Maya Zen', '6', 'Yoga instructor focusing on balance, breathing, and mindfulness.', 'images/n2.jpg', 0, 3, 4, 19, 6),
(17, 'Liam Peace', '5', 'Yoga instructor focusing on balance, breathing, and mindfulness.', 'images/n2.jpg', 0, 5, 4, 20, 2),
(18, 'Olivia Stretch', '4', 'Yoga instructor focusing on balance, breathing, and mindfulness.', 'images/n2.jpg', 0, 5, 4, 21, 0),
(19, 'Zoe Balance', '7', 'Yoga instructor focusing on balance, breathing, and mindfulness.', 'images/n2.jpg', 0, 3, 4, 22, 7),
(20, 'Noah Calm', '3', 'Yoga instructor focusing on balance, breathing, and mindfulness.', 'images/n2.jpg', 0, 3, 4, 23, 6),
(21, 'Jamal Dhamsha', '3', 'Certified nutritionist offering personalized meal plans and health coaching.', 'images/n9.jpg', 22, 5, 1, 24, 0),
(22, 'michaell bobo', '5', 'sanlkadn;fdamblkad;  dhsh;hal;', 'images/bobo.png', 50, 2, 2, 3, 4),
(23, 'Eric Steel', '5', 'Experienced trainer in strength and conditioning.', 'images/n5.jpg', 30, 5, 1, 25, 2),
(24, 'Victor Power', '6', 'Professional boxing coach with focus on technique.', 'images/n2.jpg', 28, 5, 2, 26, 1),
(25, 'Lucas Storm', '4', 'Calisthenics specialist for all levels.', 'images/n3.jpg', 27, 2, 3, 27, 8),
(26, 'Marc Strike', '7', 'Yoga instructor focusing on flexibility and balance.', 'images/n4.jpg', 35, 5, 4, 28, 1),
(27, 'Nick Blaze', '5', 'Nutrition and weight loss expert.', 'images/n11.jpg', 32, 5, 1, 29, 1),
(28, 'Patrick Swift', '6', 'Boxing trainer for beginners and advanced.', 'images/n2.jpg', 29, 5, 2, 30, 2),
(29, 'Brian Flash', '4', 'Bodyweight training and calisthenics programs.', 'images/n3.jpg', 31, 5, 3, 31, 0),
(30, 'Kevin Wolf', '6', 'Yoga flow instructor for stress relief.', 'images/n4.jpg', 34, 5, 4, 32, 1),
(31, 'Arthur Stone', '5', 'Sports nutritionist for athletes.', 'images/n3.jpg', 33, 2, 1, 33, 8),
(32, 'Samuel River', '7', 'Boxing strength and conditioning coach.', 'images/n2.jpg', 28, 5, 2, 34, 2),
(33, 'George Hawk', '3', 'Calisthenics balance and mobility expert.', 'images/n3.jpg', 30, 4, 3, 35, 3),
(34, 'Owen Frost', '5', 'Yoga instructor focusing on breathing techniques.', 'images/n4.jpg', 36, 5, 4, 36, 1),
(35, 'Steven Tide', '4', 'Certified nutritionist with 4 years experience.', 'images/n7.jpg', 27, 4, 1, 37, 4),
(36, 'Harry Bolt', '6', 'Boxing coach specialized in defensive tactics.', 'images/n2.jpg', 29, 5, 2, 38, 1),
(37, 'Adam Tiger', '5', 'Calisthenics and muscle control trainer.', 'images/n3.jpg', 31, 5, 3, 39, 1),
(38, 'Paul Shadow', '7', 'Yoga meditation and mindfulness teacher.', 'images/n4.jpg', 35, 5, 4, 40, 2),
(39, 'Matt Drake', '6', 'Sports diet and nutrition planning expert.', 'images/n8.jpg', 33, 5, 1, 41, 1),
(40, 'Shawn Peak', '4', 'Boxing fitness and agility trainer.', 'images/n2.jpg', 32, 3, 2, 42, 6),
(41, 'Frank Lion', '5', 'Calisthenics and functional training programs.', 'images/n3.jpg', 34, 5, 3, 43, 0);

-- --------------------------------------------------------

--
-- Table structure for table `trainer_orders`
--

CREATE TABLE `trainer_orders` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `trainer_id` int(11) NOT NULL,
  `package_type` varchar(20) NOT NULL,
  `height` int(11) NOT NULL,
  `weight` int(11) NOT NULL,
  `age` int(11) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `notes` text DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `order_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `program_end_date` date DEFAULT NULL,
  `is_completed` tinyint(1) DEFAULT 0,
  `meeting_day` varchar(20) DEFAULT NULL,
  `meeting_time` varchar(5) DEFAULT NULL,
  `last_late_point_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `trainer_orders`
--

INSERT INTO `trainer_orders` (`id`, `user_id`, `trainer_id`, `package_type`, `height`, `weight`, `age`, `gender`, `notes`, `photo`, `order_date`, `program_end_date`, `is_completed`, `meeting_day`, `meeting_time`, `last_late_point_date`) VALUES
(1, 1, 1, 'regular', 177, 85, 26, 'Male', 'ksnhklhds.nvk; abndk;vh;adslhv;as', 'images/Flux_Dev_a_breathtakingly_vibrant_and_whimsical_cartoonstyle_d_3.jpg', '2025-08-07 00:33:09', NULL, 0, NULL, NULL, NULL),
(12, 1, 22, 'regular', 175, 75, 28, 'Male', NULL, NULL, '2025-08-01 21:00:00', NULL, 0, 'Sunday', '10:00', '2025-08-10'),
(13, 2, 22, 'premium', 170, 60, 22, 'Male', '', '', '2025-08-07 15:13:42', NULL, 0, 'Monday', '11:00', '2025-08-10'),
(14, 2, 22, 'premium', 170, 60, 22, 'Male', '', '', '2025-08-06 15:19:29', NULL, 0, 'Monday', '12:00', '2025-08-10'),
(15, 1, 22, 'premium', 178, 85, 26, 'Male', 'dknh;ladh ad.nv;ahdjv\'  ad.khvo;ahli', 'images/back.jpg', '2025-08-10 18:48:38', '2025-10-01', 1, 'Sunday', '12:00', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `trainer_results`
--

CREATE TABLE `trainer_results` (
  `id` int(11) NOT NULL,
  `trainer_id` int(11) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `trainer_results`
--

INSERT INTO `trainer_results` (`id`, `trainer_id`, `image`) VALUES
(1, 1, 'images/result1.jpg'),
(2, 1, 'images/result2.jpg'),
(3, 2, 'images/result3.jpg'),
(4, 2, 'images/result4.jpg'),
(9, 22, 'images/Flux_Dev_a_mesmerizing_whimsical_illustration_in_the_iconic_Di_3.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(20) NOT NULL,
  `username` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `firstname` varchar(20) NOT NULL,
  `lastname` varchar(20) NOT NULL,
  `password` varchar(100) NOT NULL,
  `trainer` int(10) NOT NULL DEFAULT 0,
  `forget` int(20) NOT NULL DEFAULT 0,
  `count` int(20) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `firstname`, `lastname`, `password`, `trainer`, `forget`, `count`) VALUES
(1, 'ameer10', 'ameer_edghim@hotmail.com', 'ameer', 'edghim', 'A123456', 0, 0, 2),
(2, 'wael20', 'wael.20@gmail.com', 'wael', 'kirsh', '654321', 0, 0, 0),
(3, 'lala50', 'lala20@gmail.com', 'michaell', 'bobo', '999999', 1, 0, 0),
(4, 'trainer1', 'danagreen@gmail.com', 'Dana', 'Green', 'A123456', 1, 0, 0),
(5, 'trainer2', 'michaelnutri@gmail.com', 'Michael', 'Nutri', 'A123456', 1, 0, 0),
(6, 'trainer3', 'sarafit@gmail.com', 'Sara', 'Fit', 'A123456', 1, 0, 0),
(7, 'trainer4', 'tomhealth@gmail.com', 'Tom', 'Health', 'A123456', 1, 0, 0),
(8, 'trainer5', 'emilywellness@gmail.com', 'Emily', 'Wellness', 'A123456', 1, 0, 0),
(9, 'trainer6', 'alexpunch@gmail.com', 'Alex', 'Punch', 'A123456', 1, 0, 0),
(10, 'trainer7', 'johnjab@gmail.com', 'John', 'Jab', 'A123456', 1, 0, 0),
(11, 'trainer8', 'lisahook@gmail.com', 'Lisa', 'Hook', 'A123456', 1, 0, 0),
(12, 'trainer9', 'chrisuppercut@gmail.com', 'Chris', 'Uppercut', 'A123456', 1, 0, 0),
(13, 'trainer10', 'nataliestrike@gmail.com', 'Natalie', 'Strike', 'A123456', 1, 0, 0),
(14, 'trainer11', 'benflow@gmail.com', 'Ben', 'Flow', 'A123456', 1, 0, 0),
(15, 'trainer12', 'annapower@gmail.com', 'Anna', 'Power', 'A123456', 1, 0, 0),
(16, 'trainer13', 'davidbars@gmail.com', 'David', 'Bars', 'A123456', 1, 0, 0),
(17, 'trainer14', 'sophiecontrol@gmail.com', 'Sophie', 'Control', 'A123456', 1, 0, 0),
(18, 'trainer15', 'leomoves@gmail.com', 'Leo', 'Moves', 'A123456', 1, 0, 0),
(19, 'trainer16', 'mayazen@gmail.com', 'Maya', 'Zen', 'A123456', 1, 0, 0),
(20, 'trainer17', 'liampeace@gmail.com', 'Liam', 'Peace', 'A123456', 1, 0, 0),
(21, 'trainer18', 'oliviastretch@gmail.com', 'Olivia', 'Stretch', 'A123456', 1, 0, 0),
(22, 'trainer19', 'zoebalance@gmail.com', 'Zoe', 'Balance', 'A123456', 1, 0, 0),
(23, 'trainer20', 'noahcalm@gmail.com', 'Noah', 'Calm', 'A123456', 1, 0, 0),
(24, 'trainer21', 'jamaldhamsha@gmail.com', 'Jamal', 'Dhamsha', 'A123456', 1, 0, 0),
(25, 'trainer22', 'ericsteel@gmail.com', 'Eric', 'Steel', 'A123456', 1, 0, 0),
(26, 'trainer23', 'victorpower@gmail.com', 'Victor', 'Power', 'A123456', 1, 0, 0),
(27, 'trainer24', 'lucasstorm@gmail.com', 'Lucas', 'Storm', 'A123456', 1, 0, 0),
(28, 'trainer25', 'marcstrike@gmail.com', 'Marc', 'Strike', 'A123456', 1, 0, 0),
(29, 'trainer26', 'nickblaze@gmail.com', 'Nick', 'Blaze', 'A123456', 1, 0, 0),
(30, 'trainer27', 'patrickswift@gmail.com', 'Patrick', 'Swift', 'A123456', 1, 0, 0),
(31, 'trainer28', 'brianflash@gmail.com', 'Brian', 'Flash', 'A123456', 1, 0, 0),
(32, 'trainer29', 'kevinwolf@gmail.com', 'Kevin', 'Wolf', 'A123456', 1, 0, 0),
(33, 'trainer30', 'arthurstone@gmail.com', 'Arthur', 'Stone', 'A123456', 1, 0, 0),
(34, 'trainer31', 'samuelriver@gmail.com', 'Samuel', 'River', 'A123456', 1, 0, 0),
(35, 'trainer32', 'georgehawk@gmail.com', 'George', 'Hawk', 'A123456', 1, 0, 0),
(36, 'trainer33', 'owenfrost@gmail.com', 'Owen', 'Frost', 'A123456', 1, 0, 0),
(37, 'trainer34', 'steventide@gmail.com', 'Steven', 'Tide', 'A123456', 1, 0, 0),
(38, 'trainer35', 'harrybolt@gmail.com', 'Harry', 'Bolt', 'A123456', 1, 0, 0),
(39, 'trainer36', 'adamtiger@gmail.com', 'Adam', 'Tiger', 'A123456', 1, 0, 0),
(40, 'trainer37', 'paulshadow@gmail.com', 'Paul', 'Shadow', 'A123456', 1, 0, 0),
(41, 'trainer38', 'mattdrake@gmail.com', 'Matt', 'Drake', 'A123456', 1, 0, 0),
(42, 'trainer39', 'shawnpeak@gmail.com', 'Shawn', 'Peak', 'A123456', 1, 0, 0),
(43, 'trainer40', 'franklion@gmail.com', 'Frank', 'Lion', 'A123456', 1, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `work_programs`
--

CREATE TABLE `work_programs` (
  `id` int(11) NOT NULL,
  `order_id` int(11) DEFAULT NULL,
  `week` int(11) DEFAULT NULL,
  `sunday` text DEFAULT NULL,
  `monday` text DEFAULT NULL,
  `tuesday` text DEFAULT NULL,
  `wednesday` text DEFAULT NULL,
  `thursday` text DEFAULT NULL,
  `friday` text DEFAULT NULL,
  `saturday` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `work_programs`
--

INSERT INTO `work_programs` (`id`, `order_id`, `week`, `sunday`, `monday`, `tuesday`, `wednesday`, `thursday`, `friday`, `saturday`) VALUES
(25, 15, 1, 'adf das;\r\n', 'dssdav', '', 'sgagvs', '', '', ''),
(26, 15, 2, '', '', '', '', '', '', ''),
(27, 15, 3, '', '', 'sfgfg', '', '', '', ''),
(28, 15, 4, 'sfbgsa', '', '', '', '', 'sgfbgssfgbgs ', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories_new`
--
ALTER TABLE `categories_new`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_messages_order` (`order_id`,`created_at`);

--
-- Indexes for table `packages`
--
ALTER TABLE `packages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `trainer_id` (`trainer_id`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_review` (`user_id`,`trainer_id`),
  ADD KEY `idx_trainer` (`trainer_id`);

--
-- Indexes for table `trainers`
--
ALTER TABLE `trainers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category_id` (`category_id`),
  ADD KEY `fk_trainer_user` (`user_id`);

--
-- Indexes for table `trainer_orders`
--
ALTER TABLE `trainer_orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `trainer_id` (`trainer_id`);

--
-- Indexes for table `trainer_results`
--
ALTER TABLE `trainer_results`
  ADD PRIMARY KEY (`id`),
  ADD KEY `trainer_id` (`trainer_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `work_programs`
--
ALTER TABLE `work_programs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_order_id` (`order_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories_new`
--
ALTER TABLE `categories_new`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `packages`
--
ALTER TABLE `packages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=135;

--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `trainers`
--
ALTER TABLE `trainers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `trainer_orders`
--
ALTER TABLE `trainer_orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `trainer_results`
--
ALTER TABLE `trainer_results`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT for table `work_programs`
--
ALTER TABLE `work_programs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `packages`
--
ALTER TABLE `packages`
  ADD CONSTRAINT `packages_ibfk_1` FOREIGN KEY (`trainer_id`) REFERENCES `trainers` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `reviews`
--
ALTER TABLE `reviews`
  ADD CONSTRAINT `fk_reviews_trainer` FOREIGN KEY (`trainer_id`) REFERENCES `trainers` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_reviews_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `trainers`
--
ALTER TABLE `trainers`
  ADD CONSTRAINT `fk_trainer_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `trainers_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories_new` (`id`);

--
-- Constraints for table `trainer_orders`
--
ALTER TABLE `trainer_orders`
  ADD CONSTRAINT `trainer_orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `trainer_orders_ibfk_2` FOREIGN KEY (`trainer_id`) REFERENCES `trainers` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `trainer_results`
--
ALTER TABLE `trainer_results`
  ADD CONSTRAINT `trainer_results_ibfk_1` FOREIGN KEY (`trainer_id`) REFERENCES `trainers` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `work_programs`
--
ALTER TABLE `work_programs`
  ADD CONSTRAINT `fk_order_id` FOREIGN KEY (`order_id`) REFERENCES `trainer_orders` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
