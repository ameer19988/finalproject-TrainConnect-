<?php
include 'db_connection.php';
$con = OpenCon();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Reset Password</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            background-color: #f7f7f7;
        }
        .form-container {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 350px;
            text-align: center;
        }
        .form-container input, .form-container button {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .form-container button {
            background-color: #007bff;
            color: white;
            border: none;
            cursor: pointer;
        }
        .form-container button:hover {
            background-color: #0056b3;
        }
        .info-msg { color: #007bff; }
        .err-msg { color: #e74c3c; }
    </style>
</head>
<body>
    <div class="form-container">
        <form method="POST">
            <label for="email">Enter Your Email:</label>
            <input type="email" name="email" id="email" placeholder="Your email address" required>
            <button type="submit" name="generate">Generate New Password</button>
        </form>

        <?php
        if (isset($_POST['generate'])) {
            $email = $_POST['email'];
            $result = mysqli_query($con, "SELECT * FROM users WHERE email = '$email'");
            if ($row = mysqli_fetch_assoc($result)) {
                $str = 'qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM1234567890';
                $pas = '';
                for ($i = 0; $i < 6; $i++) {
                    $ind = rand(0, strlen($str) - 1);
                    $pas .= $str[$ind];
                }
                $update = mysqli_query($con, "UPDATE users SET password='$pas', forget=1 WHERE email='$email'");
                if ($update) {
                    echo "<div class='info-msg'>A new password was generated and set for your account.<br><b>Password: $pas</b></div>";

                    $to = $email;
                    $subject = "This is your code";
                    $message = "<br/><b>This is your code</b><br/>$pas";
                    $message .= '<br/><a href="http://localhost/finalproject/login.php">Click here to reset your password</a><br/>';
                    $header = "From:ameeredghim0@gmail.com \r\n";
                    $header .= "MIME-Version: 1.0\r\n";
                    $header .= "Content-type: text/html\r\n";

                    $retval = mail($to, $subject, $message, $header);
                    if ($retval == true) {
                        echo "Message sent successfully...";
                    } else {
                        echo "Message could not be sent...";
                    }
                } else {
                    echo "<div class='err-msg'>Failed to update password in database.</div>";
                }
            } else {
                echo "<div class='err-msg'>This email does not exist in our system.</div>";
            }
        }
        ?>
    </div>
</body>
</html>
