<?php include 'navbar.php';

 ?>

<!DOCTYPE html>
<html lang="he">
<head>
<meta charset="UTF-8">
<title></title>
<style>
body {margin:0;}
body {
      background-color: #1c1627;
      font-family: Arial, sans-serif;
      color: white;
      margin: 0;
      padding: 40px;
    }

.slider {
  position: relative;
  width: 100%;
  height: 50vh;
  overflow: hidden;
}

.slider img {
  position: absolute;
  width: 100%;
  height: 100%;
  object-fit: cover;
  opacity: 0;
  animation: fade 16s infinite;
}

.slider img:nth-child(1) {animation-delay: 0s;}
.slider img:nth-child(2) {animation-delay: 4s;}
.slider img:nth-child(3) {animation-delay: 8s;}
.slider img:nth-child(4) {animation-delay: 12s;}

@keyframes fade {
  0%   {opacity: 0;}
  5%   {opacity: 1;}
  25%  {opacity: 1;}
  30%  {opacity: 0;}
  100% {opacity: 0;}
}
/*style for the cards */ 
 .section {
      display: flex;
      align-items: center;
      margin-bottom: 40px;
      flex-wrap: wrap;
    }

    .section.reverse {
      flex-direction: row-reverse;
    }

    .image-box {
      flex: 1;
      padding: 10px;
    }

    .image-box img {
      width: 100%;
      border-radius: 20px;
    }

    .card {
      flex: 1;
      background-color: #2d2b3a;
      padding: 30px;
      border-radius: 20px;
      margin: 10px;
      
    }

    .card h2 {
      margin-top: 0;
      font-size: 24px;
    }

    .card p {
      color: #ccc;
    }

    .explore {
      display: flex;
      align-items: center;
      margin-top: 20px;
      color: white;
      font-weight: bold;
      text-decoration: none;
    }

    .explore .icon {
      background-color: #ff4fc1;
      color: white;
      border-radius: 50%;
      width: 35px;
      height: 35px;
      display: flex;
      align-items: center;
      justify-content: center;
      margin-right: 12px;
      font-size: 18px;
    }

    .show-on-scroll {
  opacity: 0;
  transform: translateY(50px);
  transition: opacity 0.6s ease, transform 0.6s ease;
}

.show-on-scroll.show {
  opacity: 1;
  transform: translateY(0);
}


</style>
</head>
<body>
<div class="slider">
  <img src="images/1.jpg" alt="">
  <img src="images/2.jpg" alt="">
  <img src="images/3.jpg" alt="">
  <img src="images/4.jpg" alt="">
</div>
<br/><br/>

<?php 
//CATEGORIES   
include 'categories.php';
 ?>

<div class="section show-on-scroll">
<!-- Section 1 -->
  <div class="section">
    <div class="image-box">
      <img src="images/1122.jpg" alt="fitness">
    </div>
    <div class="card">
      <h2>GET INSPIRED</h2>
      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in eros elementum tristique.</p>
      <a href="#" class="explore">
        <div class="icon">↗</div>
        Explore More
      </a>
    </div>
  </div>
  </div>

<div class="section show-on-scroll">
  <!-- Section 2 -->
  <div class="section reverse">
    <div class="image-box">
      <img src="https://images.unsplash.com/photo-1605296867304-46d5465a13f1" alt="fitness">
    </div>
    <div class="card">
      <h2>CHALLENGE YOURSELF</h2>
      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in eros elementum tristique.</p>
      <a href="#" class="explore">
        <div class="icon">↗</div>
        Explore More
      </a>
    </div>
  </div>
</div>




<script>
  const elements = document.querySelectorAll('.show-on-scroll');

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('show');
      }
    });
  });

  elements.forEach(el => observer.observe(el));
</script>
</body>
</html>
