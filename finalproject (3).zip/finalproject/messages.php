<?php
// messages.php — +1 point per late reply (once per client message), then recalc rating
session_start();
include 'navbar.php';
include_once 'db_connection.php';
include_once 'rating_helpers.php'; // recalc_trainer_rating($con, $trainer_id)
$con = OpenCon();

if (!isset($_SESSION['logged_in_user'])) { exit("Please login first."); }

$username   = $_SESSION['logged_in_user'];
$is_trainer = (isset($_SESSION['is_trainer']) && $_SESSION['is_trainer'] == 1) ? 1 : 0;

/* current user id */
$uRes = mysqli_query($con, "SELECT id FROM users WHERE username='$username'");
if (!$uRes || mysqli_num_rows($uRes)==0) exit("User not found.");
$my_user_id = (int)mysqli_fetch_assoc($uRes)['id'];

/* which order */
$order_id = isset($_GET['order_id']) ? (int)$_GET['order_id'] : 0;
if ($order_id <= 0) exit("Missing order_id.");

$oRes = mysqli_query($con, "SELECT * FROM trainer_orders WHERE id=$order_id");
if (!$oRes || mysqli_num_rows($oRes)==0) exit("Order not found.");
$order = mysqli_fetch_assoc($oRes);

$trainer_id = (int)$order['trainer_id'];
$client_id  = (int)$order['user_id'];
$package    = strtolower($order['package_type']); // 'regular' | 'premium'

/* auth */
if (!$is_trainer && $client_id !== $my_user_id) exit("Not allowed.");
if ($is_trainer) {
    $tRes = mysqli_query($con, "SELECT id FROM trainers WHERE user_id=$my_user_id");
    if (!$tRes || mysqli_num_rows($tRes)==0) exit("Not a trainer.");
    $me_trainer_id = (int)mysqli_fetch_assoc($tRes)['id'];
    if ($me_trainer_id !== $trainer_id) exit("Not your order.");
}

/* days per package */
$days_to_answer = ($package === 'premium') ? 1 : 3;

/* -------- SEND MESSAGE -------- */
if (isset($_POST['send_msg'])) {
    $text = isset($_POST['message_text']) ? trim($_POST['message_text']) : '';
    if ($text !== '') {
        $safe = mysqli_real_escape_string($con, $text);

        if ($is_trainer) {
            // 1) insert trainer message
            $ins = mysqli_query($con, "
              INSERT INTO messages (order_id, trainer_id, user_id, sender, message_text)
              VALUES ($order_id, $trainer_id, $client_id, 'trainer', '$safe')
            ");
            if ($ins) {
                $trainerMsgId  = mysqli_insert_id($con);
                $tmRes = mysqli_query($con, "SELECT created_at FROM messages WHERE id=$trainerMsgId");
                $trainerSentAt = ($tmRes && mysqli_num_rows($tmRes)>0)
                                  ? strtotime(mysqli_fetch_assoc($tmRes)['created_at'])
                                  : time();

                // 2) latest client message not yet scored
                $lastUserMsgRes = mysqli_query($con, "
                  SELECT id, reply_deadline, created_at, points_given
                  FROM messages
                  WHERE order_id = $order_id
                    AND sender = 'user'
                    AND points_given = 0
                    AND created_at <= FROM_UNIXTIME($trainerSentAt)
                  ORDER BY created_at DESC
                  LIMIT 1
                ");
                if ($lastUserMsgRes && mysqli_num_rows($lastUserMsgRes)>0) {
                    $um = mysqli_fetch_assoc($lastUserMsgRes);
                    $deadline_ts = !empty($um['reply_deadline'])
                        ? strtotime($um['reply_deadline'])
                        : strtotime($um['created_at'].' +'.(($package==='premium')?1:3).' days');

                    // 3) mark replied_at
                    $trainerSentAtStr = date('Y-m-d H:i:s', $trainerSentAt);
                    mysqli_query($con, "UPDATE messages SET replied_at='$trainerSentAtStr' WHERE id={$um['id']}");

                    // 4) if late -> +1 point once, then recalc rating
                    if ($trainerSentAt > $deadline_ts) {
                        mysqli_query($con, "UPDATE trainers SET delay_points = delay_points + 1 WHERE id=$trainer_id");
                        mysqli_query($con, "UPDATE messages SET points_given = 1 WHERE id={$um['id']}");

                        // recalc rating after point change
                        recalc_trainer_rating($con, $trainer_id);
                    }
                }
            }
        } else {
            // client message -> set deadline now
            $deadline = date('Y-m-d H:i:s', strtotime("+$days_to_answer days"));
            mysqli_query($con, "
              INSERT INTO messages (order_id, trainer_id, user_id, sender, message_text, reply_deadline)
              VALUES ($order_id, $trainer_id, $client_id, 'user', '$safe', '$deadline')
            ");
        }
    }
    header("Location: messages.php?order_id=".$order_id);
    exit();
}

/* -------- CONVERSATION -------- */
$msgRes = mysqli_query($con, "
  SELECT id, sender, message_text, created_at, reply_deadline, replied_at
  FROM messages
  WHERE order_id=$order_id
  ORDER BY created_at ASC
");
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Messages</title>
<style>
body { font-family: Arial, sans-serif; margin: 0; padding: 0; background: url('images/back2.png') center/cover fixed no-repeat; color: #f5f6f8; }
.wrap { max-width: 900px; margin: 30px auto; background: rgba(0,0,0,.55); backdrop-filter: blur(8px); -webkit-backdrop-filter: blur(8px); padding: 22px; border-radius: 14px; box-shadow: 0 10px 30px rgba(0,0,0,.35); border: 1px solid rgba(255,255,255,.18); display: flex; flex-direction: column; gap: 12px; }
h2 { margin: 0 0 4px; text-align: center; color: #ffe08a; }
.bubble { padding: 10px 12px; border-radius: 14px; display: inline-block; max-width: 75%; white-space: pre-wrap; line-height: 1.4; box-shadow: 0 6px 16px rgba(0,0,0,.25); align-self: flex-start; }
.me { background: rgba(64,164,255,.18); color: #e8f3ff; border: 1px solid rgba(64,164,255,.35); align-self: flex-end; }
.other { background: rgba(255,255,255,.08); color: #fff; border: 1px solid rgba(255,255,255,.22); }
.meta { font-size: 12px; color: #cfd2d8; margin-top: 6px; }
.form { margin-top: 6px; display: flex; gap: 8px; }
.form textarea { flex: 1; height: 80px; border: 1px solid rgba(255,255,255,.22); border-radius: 10px; padding: 10px; background: rgba(255,255,255,.08); color: #fff; resize: vertical; box-sizing: border-box; }
.form textarea::placeholder { color: #cfd2d8; }
.form button { padding: 10px 16px; border: none; border-radius: 10px; background: #ff8c3a; color: #fff; font-weight: 700; cursor: pointer; box-shadow: 0 8px 20px rgba(0,0,0,.30); transition: transform .15s, background .15s; }
.form button:hover { background: #e77a2f; transform: translateY(-2px); }
.info-message { text-align: center; background: rgba(255,255,255,.08); border: 1px solid rgba(255,255,255,.25); border-radius: 10px; padding: 10px; margin: 10px 0; color: #ffe08a; }

</style>
</head>
<body>
<div class="wrap">
  <h2>Conversation (Order #<?php echo $order_id; ?>)</h2>

  <?php if ($msgRes && mysqli_num_rows($msgRes) > 0): ?>
    <?php while ($m = mysqli_fetch_assoc($msgRes)):
      $mine = ($is_trainer ? $m['sender']=='trainer' : $m['sender']=='user');
    ?>
      <div class="bubble <?php echo $mine ? 'me' : 'other'; ?>">
        <?php echo htmlspecialchars($m['message_text']); ?>
        <div class="meta">
          <?php echo $m['sender']; ?> · <?php echo $m['created_at']; ?>
          <?php if ($m['sender']=='user' && !empty($m['reply_deadline'])): ?>
            · deadline: <?php echo $m['reply_deadline']; ?>
          <?php endif; ?>
          <?php if ($m['sender']=='user' && !empty($m['replied_at'])): ?>
            · replied: <?php echo $m['replied_at']; ?>
          <?php endif; ?>
        </div>
      </div>
    <?php endwhile; ?>
  <?php else: ?>
    <p style="color:#666;">No messages yet.</p>
  <?php endif; ?>

  <form method="post" class="form">
    <textarea name="message_text" placeholder="Type your message..."></textarea>
    <button type="submit" name="send_msg">Send</button>
  </form>
</div>
</body>
</html>
