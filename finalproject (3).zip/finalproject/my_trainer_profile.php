<?php
session_start();
include_once 'db_connection.php';
include 'navbar.php';
$con = OpenCon();

if (!isset($_SESSION['logged_in_user']) || !isset($_SESSION['is_trainer']) || $_SESSION['is_trainer'] != 1) {
    header("Location: login.php");
    exit();
}

// Get trainer info
$user = $_SESSION['logged_in_user'];
$res = mysqli_query($con, "SELECT id FROM users WHERE username = '$user'");
$user_row = mysqli_fetch_assoc($res);
$user_id = $user_row['id'];

$trainer_query = "SELECT * FROM trainers WHERE user_id = '$user_id'";
$trainer_result = mysqli_query($con, $trainer_query);
$trainer = mysqli_fetch_assoc($trainer_result);

if (!$trainer) {
    echo "<div class='info-message'>You are not registered as a trainer.</div>";
    exit();
}

// Get category name
$cat_id = $trainer['category_id'];
$cat_res = mysqli_query($con, "SELECT name FROM categories_new WHERE id = '$cat_id'");
$cat_row = mysqli_fetch_assoc($cat_res);
$category = $cat_row ? $cat_row['name'] : "Unknown";

// Get packages
$packages = [];
$pkg_res = mysqli_query($con, "SELECT * FROM packages WHERE trainer_id = {$trainer['id']}");
while ($row = mysqli_fetch_assoc($pkg_res)) {
    $packages[] = $row;
}

// Get result images
$results = [];
$res_img = mysqli_query($con, "SELECT image FROM trainer_results WHERE trainer_id = {$trainer['id']}");
while ($row = mysqli_fetch_assoc($res_img)) {
    $results[] = $row['image'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>My Trainer Profile</title>
<style>
  body { font-family: Arial, sans-serif; margin: 0; padding: 0; background: url('images/back2.png') center/cover fixed no-repeat; color: #f5f6f8; }
.profile-container { max-width: 760px; margin: 40px auto; background: rgba(0,0,0,.55); backdrop-filter: blur(8px); -webkit-backdrop-filter: blur(8px); border-radius: 16px; box-shadow: 0 10px 30px rgba(0,0,0,.35); padding: 28px; border: 1px solid rgba(255,255,255,.18); }
.profile-header { display: flex; align-items: center; gap: 24px; margin-bottom: 24px; }
.profile-header img { width: 130px; height: 130px; object-fit: cover; border-radius: 100px; border: 2px solid rgba(255,255,255,.25); }
.profile-details h2 { margin: 0; color: #ffe08a; }
.profile-details p { margin: 6px 0; color: #e6e7ea; }
.cat-label { background: rgba(64,164,255,.18); color: #e8f3ff; padding: 4px 10px; border-radius: 999px; font-size: 14px; display: inline-block; border: 1px solid rgba(64,164,255,.35); }
.section { margin-bottom: 22px; }
.section-title { font-size: 1.1em; font-weight: 800; margin-bottom: 10px; color: #fff; }
.packages { display: flex; gap: 12px; flex-wrap: wrap; }
.package-card { background: rgba(255,255,255,.08); padding: 10px 16px; border-radius: 10px; min-width: 130px; border: 1px solid rgba(255,255,255,.22); color: #fff; }
.results-list { display: flex; gap: 12px; flex-wrap: wrap; }
.results-list img { width: 110px; height: 110px; object-fit: cover; border-radius: 10px; border: 1px solid rgba(255,255,255,.22); }
.edit-btn { margin-top: 8px; background: #ff8c3a; color: #fff; border: none; border-radius: 10px; padding: 10px 22px; font-size: 1em; cursor: pointer; box-shadow: 0 8px 20px rgba(0,0,0,.30); transition: transform .15s, background .15s; }
.edit-btn:hover { background: #e77a2f; transform: translateY(-2px); }
.info-message { text-align: center; color: #ffe08a; background: rgba(255,255,255,.08); border: 1px solid rgba(255,255,255,.25); border-radius: 10px; padding: 11px; margin-bottom: 16px; }

</style>
</head>
<body>
<div class="profile-container">
  <div class="profile-header">
    <img src="<?php echo htmlspecialchars($trainer['image']); ?>" alt="Trainer Photo">
    <div class="profile-details">
      <h2><?php echo htmlspecialchars($trainer['name']); ?></h2>
      <span class="cat-label"><?php echo htmlspecialchars($category); ?></span>
      <p><b>Experience:</b> <?php echo htmlspecialchars($trainer['experience']); ?> years</p>
      <p><b>Age:</b> <?php echo htmlspecialchars($trainer['age']); ?></p>
    </div>
  </div>

  <div class="section">
    <div class="section-title">About</div>
    <div><?php echo nl2br(htmlspecialchars($trainer['description'])); ?></div>
  </div>

  <div class="section">
    <div class="section-title">Packages</div>
    <div class="packages">
      <?php foreach ($packages as $pkg): ?>
        <div class="package-card">
          <b><?php echo ucfirst($pkg['type']); ?>:</b>
          <div><?php echo $pkg['price']; ?> ₪</div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>

  <div class="section">
    <div class="section-title">Result Photos</div>
    <div class="results-list">
      <?php if (count($results) > 0): ?>
        <?php foreach ($results as $img): ?>
          <img src="<?php echo htmlspecialchars($img); ?>" alt="Result Photo">
        <?php endforeach; ?>
      <?php else: ?>
        <span style="color:#888;">No result photos uploaded yet.</span>
      <?php endif; ?>
    </div>
  </div>

  <form method="get" action="edit_trainer_profile.php">
    <button class="edit-btn" type="submit">Edit Profile</button>
  </form>
</div>
</body>
</html>
