<?php
/**
 * daily_maintenance.php
 *
 * Run once per day (Windows Task Scheduler).
 * - Programs: +1 point per overdue day until completed. Uses trainer_orders.last_late_point_date.
 * - Messages: +1 point per overdue day per client message until trainer replies. Uses messages.last_point_date.
 * - Meetings cleanup: clears meeting_day/meeting_time after program_end_date.
 *
 * NO JOINS are used (per request).
 */

date_default_timezone_set('Asia/Jerusalem');

require_once 'db_connection.php';
require_once 'rating_helpers.php'; // recalc_trainer_rating($con, $trainer_id)
$con = OpenCon();

$todayDate = date('Y-m-d');
$nowTs     = time();

/* =========================================================
   1) OVERDUE PROGRAM BUILDS  (+1 point per overdue day)
   ---------------------------------------------------------
   - premium: must finish within 1 day of order_date
   - regular: must finish within 3 days of order_date
   - If today > deadline_date AND last_late_point_date < today:
       => +1 to trainers.delay_points
       => set trainer_orders.last_late_point_date = today
       => recalc rating
   ========================================================= */

$ordersRes = mysqli_query($con, "
    SELECT id, trainer_id, package_type, order_date, is_completed, last_late_point_date
    FROM trainer_orders
");
if ($ordersRes) {
    while ($o = mysqli_fetch_assoc($ordersRes)) {
        $order_id   = (int)$o['id'];
        $trainer_id = (int)$o['trainer_id'];
        $pkg        = strtolower(trim((string)$o['package_type']));
        $order_date = (string)$o['order_date'];
        $is_completed = (int)$o['is_completed'];
        $last_point = $o['last_late_point_date']; // can be NULL

        // Only consider not-completed
        if ($is_completed === 1) continue;

        // Compute deadline date
        $days_to_finish = ($pkg === 'premium') ? 1 : 3;
        $deadline_date  = date('Y-m-d', strtotime($order_date . " +$days_to_finish days"));

        // Overdue if today is strictly after deadline day
        if ($todayDate > $deadline_date) {
            // Award exactly once per calendar day
            if (is_null($last_point) || $last_point < $todayDate) {
                mysqli_query($con, "UPDATE trainers SET delay_points = delay_points + 1 WHERE id = $trainer_id");
                mysqli_query($con, "UPDATE trainer_orders SET last_late_point_date = '$todayDate' WHERE id = $order_id");

                // Recalculate rating for this trainer
                recalc_trainer_rating($con, $trainer_id);
            }
        }
    }
}

/* =========================================================
   2) OVERDUE MESSAGES (+1 point per overdue day per message)
   ---------------------------------------------------------
   For each client message (sender='user'):
     - Deadline = reply_deadline if set, otherwise created_at + SLA days
       (SLA days derived from the message's order package_type)
     - If overdue AND no trainer reply after that message:
         if last_point_date < today => +1 point & update last_point_date=today
   ========================================================= */

// Fetch client messages only (no join)
$msgRes = mysqli_query($con, "
    SELECT id, order_id, trainer_id, sender, message_text, created_at, reply_deadline, last_point_date
    FROM messages
    WHERE sender = 'user'
");
if ($msgRes) {
    while ($m = mysqli_fetch_assoc($msgRes)) {
        $msg_id     = (int)$m['id'];
        $order_id   = (int)$m['order_id'];
        $trainer_id = (int)$m['trainer_id'];
        $created_at = (string)$m['created_at'];
        $reply_deadline = $m['reply_deadline']; // can be NULL
        $last_point = $m['last_point_date'];    // can be NULL

        // 2.a) Get the order to determine package_type (no join, separate query)
        $ordRes = mysqli_query($con, "SELECT package_type FROM trainer_orders WHERE id = $order_id");
        if (!$ordRes || mysqli_num_rows($ordRes) === 0) {
            continue; // order missing? skip safely
        }
        $ord = mysqli_fetch_assoc($ordRes);
        $pkg = strtolower(trim((string)$ord['package_type']));
        $sla_days = ($pkg === 'premium') ? 1 : 3;

        // 2.b) Compute the deadline TS
        if (!empty($reply_deadline)) {
            $deadlineTs = strtotime($reply_deadline);
        } else {
            $deadlineTs = strtotime($created_at . " +$sla_days days");
        }

        // If not overdue, skip
        if ($nowTs <= $deadlineTs) continue;

        // 2.c) Check if a trainer reply exists AFTER this client message
        $created_at_esc = mysqli_real_escape_string($con, $created_at);
        $repRes = mysqli_query($con, "
            SELECT id FROM messages
            WHERE order_id = $order_id
              AND sender = 'trainer'
              AND created_at > '$created_at_esc'
            LIMIT 1
        ");
        $hasReplyAfter = ($repRes && mysqli_num_rows($repRes) > 0);
        if ($hasReplyAfter) continue; // once trainer replied, stop awarding points for this message

        // 2.d) Overdue and still unanswered -> award once per calendar day
        if (is_null($last_point) || $last_point < $todayDate) {
            mysqli_query($con, "UPDATE trainers SET delay_points = delay_points + 1 WHERE id = $trainer_id");
            mysqli_query($con, "UPDATE messages SET last_point_date = '$todayDate' WHERE id = $msg_id");

            // Recalc rating for this trainer
            recalc_trainer_rating($con, $trainer_id);
        }
    }
}

/* =========================================================
   3) MEETINGS CLEANUP
   ---------------------------------------------------------
   When program_end_date has passed, remove meeting_day/time
   so they won't show in trainer_meetings.php
   ========================================================= */

mysqli_query($con, "
    UPDATE trainer_orders
    SET meeting_day = NULL,
        meeting_time = NULL
    WHERE program_end_date IS NOT NULL
      AND program_end_date < CURDATE()
      AND (meeting_day IS NOT NULL OR meeting_time IS NOT NULL)
");

echo "Daily maintenance done at " . date('Y-m-d H:i:s') . PHP_EOL;
