<?php
session_start();
include_once 'db_connection.php';
include 'navbar.php';
$con = OpenCon();

if (!isset($_SESSION['logged_in_user']) || !isset($_SESSION['is_trainer']) || $_SESSION['is_trainer'] != 1) {
    header("Location: login.php");
    exit();
}

// Get trainer and user info
$user = $_SESSION['logged_in_user'];
$res = mysqli_query($con, "SELECT id FROM users WHERE username = '$user'");
$user_row = mysqli_fetch_assoc($res);
$user_id = $user_row['id'];

$trainer_q = mysqli_query($con, "SELECT * FROM trainers WHERE user_id = '$user_id'");
$trainer = mysqli_fetch_assoc($trainer_q);

if (!$trainer) {
    echo "<div class='info-message'>You are not a trainer.</div>";
    exit();
}
$trainer_id = $trainer['id'];

// --- DELETE result photo if requested (DB only, not file) ---
if (isset($_GET['delete_result']) && is_numeric($_GET['delete_result'])) {
    $delete_id = (int)$_GET['delete_result'];
    // Confirm it belongs to this trainer
    $img_q = mysqli_query($con, "SELECT id FROM trainer_results WHERE id = $delete_id AND trainer_id = $trainer_id");
    $img = mysqli_fetch_assoc($img_q);
    if ($img) {
        mysqli_query($con, "DELETE FROM trainer_results WHERE id = $delete_id");
    }
    header("Location: edit_trainer_profile.php");
    exit();
}

// Get categories
$categories = [];
$res_cat = mysqli_query($con, "SELECT id, name FROM categories_new");
while ($row = mysqli_fetch_assoc($res_cat)) {
    $categories[] = $row;
}

// Get packages
$regular_price = "";
$premium_price = "";
$pkg_res = mysqli_query($con, "SELECT * FROM packages WHERE trainer_id = $trainer_id");
while ($row = mysqli_fetch_assoc($pkg_res)) {
    if ($row['type'] == 'regular') $regular_price = $row['price'];
    if ($row['type'] == 'premium') $premium_price = $row['price'];
}

// Get result images
$results = [];
$res_img = mysqli_query($con, "SELECT id, image FROM trainer_results WHERE trainer_id = $trainer_id");
while ($row = mysqli_fetch_assoc($res_img)) {
    $results[] = $row;
}

// ----- Handle Edit -----
if (isset($_POST['saveChanges'])) {
    $experience = $_POST['experience'];
    $age = $_POST['age'];
    $description = $_POST['description'];
    $category_id = (int)$_POST['category_id'];
    $new_regular_price = floatval($_POST['regular_price']);
    $new_premium_price = isset($_POST['premium_price']) && $_POST['premium_price'] !== '' ? floatval($_POST['premium_price']) : null;

    // Profile photo (optional)
    $image = $trainer['image'];
    if (isset($_FILES['image']) && $_FILES['image']['error'] === 0) {
        $imageName = $_FILES['image']['name'];
        $imageTmpName = $_FILES['image']['tmp_name'];
        $imageFolder = 'images/' . $imageName;
        if (move_uploaded_file($imageTmpName, $imageFolder)) {
            $image = $imageFolder;
        }
    }

    // Update trainer info
    mysqli_query($con, "UPDATE trainers SET experience='$experience', age='$age', description='$description', image='$image', category_id='$category_id' WHERE id='$trainer_id'");

    // Update packages
    mysqli_query($con, "UPDATE packages SET price=$new_regular_price WHERE trainer_id=$trainer_id AND type='regular'");
    if ($new_premium_price !== null && $new_premium_price > 0) {
        $has_premium = mysqli_query($con, "SELECT * FROM packages WHERE trainer_id=$trainer_id AND type='premium'");
        if (mysqli_num_rows($has_premium) > 0) {
            mysqli_query($con, "UPDATE packages SET price=$new_premium_price WHERE trainer_id=$trainer_id AND type='premium'");
        } else {
            mysqli_query($con, "INSERT INTO packages (trainer_id, type, price) VALUES ($trainer_id, 'premium', $new_premium_price)");
        }
    } else {
        // If removed, delete the premium package
        mysqli_query($con, "DELETE FROM packages WHERE trainer_id=$trainer_id AND type='premium'");
    }

    // Handle new result images (add up to 4 total)
    $num_existing = count($results);
    $num_upload = 0;
    if (isset($_FILES['results'])) {
        for ($i = 0; $i < 4 - $num_existing; $i++) {
            if (isset($_FILES['results']['name'][$i]) && $_FILES['results']['name'][$i] != '' && $_FILES['results']['error'][$i] === 0) {
                $resultImgName = $_FILES['results']['name'][$i];
                $resultTmpName = $_FILES['results']['tmp_name'][$i];
                $resultFolder = 'images/' . $resultImgName;
                if (move_uploaded_file($resultTmpName, $resultFolder)) {
                    mysqli_query($con, "INSERT INTO trainer_results (trainer_id, image) VALUES ($trainer_id, '$resultFolder')");
                    $num_upload++;
                }
            }
        }
    }
    header("Location: my_trainer_profile.php"); 
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Edit Trainer Profile</title>
<style>
body { font-family: Arial, sans-serif; margin: 0; padding: 0; background: url('images/back2.png') center/cover fixed no-repeat; color: #f5f6f8; }
.profile-container { max-width: 760px; margin: 40px auto; background: rgba(0,0,0,.55); backdrop-filter: blur(8px); -webkit-backdrop-filter: blur(8px); border-radius: 16px; box-shadow: 0 10px 30px rgba(0,0,0,.35); padding: 28px; border: 1px solid rgba(255,255,255,.18); }
h2 { margin-bottom: 25px; color: #ffe08a; }
.form-label { display: block; margin-bottom: 8px; color: #e6e7ea; font-size: 1em; font-weight: bold; }
.form-input, .form-textarea, .form-select { width: 100%; padding: 9px 10px; margin-bottom: 18px; border-radius: 7px; border: 1px solid rgba(255,255,255,.25); font-size: 1em; box-sizing: border-box; background: rgba(255,255,255,.08); color: #fff; transition: border 0.2s, background 0.2s; }
.form-input:focus, .form-textarea:focus, .form-select:focus { border: 1.5px solid #40a4ff; background: rgba(0,0,0,.35); outline: none; }
.form-textarea { min-height: 60px; resize: vertical; }
.result-imgs { display: flex; gap: 14px; flex-wrap: wrap; }
.result-imgs img { width: 100px; height: 100px; object-fit: cover; border-radius: 8px; border: 1px solid rgba(255,255,255,.22); }
.delete-btn { display: block; margin-top: 6px; background: #e74c3c; color: #fff; border: none; border-radius: 6px; padding: 3px 14px; font-size: 14px; cursor: pointer; text-decoration: none; text-align: center; box-shadow: 0 4px 10px rgba(0,0,0,.3); transition: background 0.15s; }
.delete-btn:hover { background: #c0392b; }
.submit-btn { width: 100%; background: #ff8c3a; color: #fff; border: none; border-radius: 30px; padding: 12px 0; font-size: 1.08em; font-weight: 600; cursor: pointer; margin-top: 8px; transition: background 0.17s, transform 0.15s; box-shadow: 0 8px 20px rgba(0,0,0,.3); }
.submit-btn:hover { background: #e77a2f; transform: translateY(-2px); }
.note { font-size: 0.97em; color: #ffe08a; margin-bottom: 7px; background: rgba(255,255,255,.08); border: 1px solid rgba(255,255,255,.25); padding: 5px 10px; border-radius: 6px; }

</style>
</head>
<body>
<div class="profile-container">
  <h2>Edit Trainer Profile</h2>
  <form method="post" enctype="multipart/form-data">
    <label class="form-label">Experience (years):</label>
    <input class="form-input" name="experience" type="number" min="0" max="70" required value="<?php echo htmlspecialchars($trainer['experience']); ?>">

    <label class="form-label">Age:</label>
    <input class="form-input" name="age" type="number" min="16" max="99" required value="<?php echo htmlspecialchars($trainer['age']); ?>">

    <label class="form-label">Description:</label>
    <textarea class="form-textarea" name="description"><?php echo htmlspecialchars($trainer['description']); ?></textarea>

    <label class="form-label">Profile Photo: <small>(leave blank to keep current)</small></label>
    <input class="form-input" name="image" type="file" accept="image/*">
    <div style="margin-bottom:18px;">
      <img src="<?php echo htmlspecialchars($trainer['image']); ?>" alt="Current Photo" width="80" style="border-radius:8px;border:1px solid #ccc;">
    </div>

    <label class="form-label">Category:</label>
    <select class="form-select" name="category_id" required>
      <option value="">Select category...</option>
      <?php foreach($categories as $cat): ?>
        <option value="<?php echo $cat['id']; ?>" <?php if ($cat['id']==$trainer['category_id']) echo "selected"; ?>>
          <?php echo htmlspecialchars($cat['name']); ?>
        </option>
      <?php endforeach; ?>
    </select>

    <label class="form-label">Regular Package Price (₪):</label>
    <input class="form-input" name="regular_price" type="number" step="0.01" min="0" required value="<?php echo htmlspecialchars($regular_price); ?>">
    <div class="note">
      <b>Regular Package:</b> Must finish the program in <b>3 days</b> and reply to clients within <b>3 days</b>.
    </div>

    <label class="form-label">Premium Package Price (₪): <small style="color:#888;">(optional)</small></label>
    <input class="form-input" name="premium_price" type="number" step="0.01" min="0" value="<?php echo htmlspecialchars($premium_price); ?>">
    <div class="note">
      <b>Premium Package:</b> Must finish the program in <b>1 day</b> and reply to clients within <b>1 day</b>.
    </div>

    <label class="form-label">Current Result Photos:</label>
    <div class="result-imgs" style="margin-bottom:10px;">
      <?php if (count($results) > 0): ?>
        <?php foreach ($results as $img): ?>
          <div style="position:relative; display:inline-block;">
            <img src="<?php echo htmlspecialchars($img['image']); ?>" alt="Result Photo">
            <a class="delete-btn" href="edit_trainer_profile.php?delete_result=<?php echo $img['id']; ?>"
                onclick="return confirm('Delete this photo?');">&times; Delete</a>
          </div>
        <?php endforeach; ?>
      <?php else: ?>
        <span style="color:#888;">No result photos uploaded yet.</span>
      <?php endif; ?>
    </div>
    <?php if (count($results) < 4): ?>
      <label class="form-label">Add More Result Photos (up to <?php echo 4 - count($results); ?>):</label>
      <?php for ($i = 0; $i < 4 - count($results); $i++): ?>
        <input class="form-input" name="results[]" type="file" accept="image/*">
      <?php endfor; ?>
    <?php endif; ?>

    <button class="submit-btn" name="saveChanges">Save Changes</button>
  </form>
</div>
</body>
</html>
