<?php include 'navbar.php'; 
include_once 'db_connection.php';
$con = OpenCon();

?>

<?php
if (isset($_POST['logInBtn'])) {
    $user = $_POST['userName'];
    $pass = $_POST['password'];

    $alert_message = ""; // נשמור כאן את ההודעה

    $result = mysqli_query($con, "SELECT * FROM users");

    if ($result) { 
        $user_found = false; 

        while ($row = mysqli_fetch_array($result)) {
            if ($row['forget'] == 0) {
                if ($row['username'] == $user) {
                    $user_found = true; 
                    if ($row['count'] >= 3) {
                        $alert_message = "Error: You already entered 3 wrong passwords.";
                        echo "<script>alert('$alert_message'); window.location='forgetpassword.php';</script>";
                        exit();
                    }
                    if ($row['trainer'] == 0) {
                        if ($row['password'] == $pass) {
                            $_SESSION['logged_in_user'] = $user; 
                            header("Location:index.php"); 
                            exit();
                        } else {
                            if ($row['count'] >= 3) {
                                $alert_message = "Error: You already entered 3 wrong passwords.";
                            } else {
                                mysqli_query($con, "UPDATE users SET count = " . ($row['count'] + 1) . " WHERE username = '$user'");
                                $alert_message = "Wrong password.";
                            }
                        }
                    } else {
                        if ($row['password'] == $pass) {
                            $_SESSION['logged_in_user'] = $user; 
                            $_SESSION['is_trainer'] = $row['trainer'];
                            header("Location: index.php"); 
                            exit();
                        } else {
                            if ($row['count'] >= 3) {
                                $alert_message = "Error: You already entered 3 wrong passwords.";
                            } else {
                                mysqli_query($con, "UPDATE users SET count = " . ($row['count'] + 1) . " WHERE username = '$user'");
                                $alert_message = "Wrong password.";
                            }
                        }
                    }

                    if (!empty($alert_message)) {
                        echo "<script>alert('$alert_message');</script>";
                    }
                }
            } else {
                header("Location: newpass.php");
                exit();
            }
        }

        if (!$user_found) {
            echo "<script>alert('Invalid user.');</script>";
        }
    } else {
        echo "<script>alert('Error: Query failed.');</script>";
    }
}
?>


<?php
$signup_error = '';

if (isset($_POST['signUpBtn'])) {
    $username = $_POST['newUser'];
    $firstname = $_POST['firstName'];
    $lastname = $_POST['lastName'];
    $email = $_POST['email'];
    $pass1 = $_POST['newPassword'];
    $pass2 = $_POST['confirmPassword'];

    if (strlen($pass1) < 6) {
        $signup_error = "Password must be at least 6 characters.";
    } elseif (!preg_match('/[A-Z]/', $pass1)) {
        $signup_error = "Password must have at least one uppercase letter.";
    } elseif ($pass1 !== $pass2) {
        $signup_error = "Passwords do not match.";
    } else {
        $check_user = mysqli_query($con, "SELECT * FROM users WHERE username = '$username'");
        if (mysqli_num_rows($check_user) > 0) {
            $signup_error = "Username already exists.";
        }

        elseif (mysqli_num_rows(mysqli_query($con, "SELECT * FROM users WHERE email = '$email'")) > 0) {
            $signup_error = "Email already exists.";
        }

        else {
            $query = "INSERT INTO users (username, firstname, lastname, email, password)
                      VALUES ('$username', '$firstname', '$lastname', '$email', '$pass1')";
            if (mysqli_query($con, $query)) {
                header("Location: login.php?registered=1");
                exit();
            } else {
                $signup_error = "Error during registration.";
            }
        }
    }
}
?>




<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
    * {
      margin: 0;
      padding: 0;
      font-family: "Poppins", sans-serif;
    }

    body {
      background: url("images/back.jpg") no-repeat center center;
      background-size: cover;
      height: 100vh;
    }

    section {
      display: flex;
      justify-content: center;
      align-items: center;
      height: 90vh;
    }

    .flip-card {
      background-color: transparent;
      width: 400px;
      height: 500px;
      perspective: 1000px;
    }

    .flip-card-inner {
      position: relative;
      width: 100%;
      height: 100%;
      transition: transform 0.8s;
      transform-style: preserve-3d;
    }

    .flipped {
      transform: rotateY(180deg);
    }

    .flip-card-front,
    .flip-card-back {
      position: absolute;
      width: 100%;
      height: 100%;
      backface-visibility: hidden;
    }

    .form-box {
      position: relative;
      width: 100%;
      height: auto; 
      background: transparent;
      border: 2px solid rgba(255, 255, 255, 0.5);
      border-radius: 20px;
      backdrop-filter: blur(15px);
      display: flex;
      justify-content: center;
      align-items: center;
      flex-direction: column;
    }

    .flip-card-front .form-box,
    .flip-card-back .form-box {
      padding: 30px;
    }

    h2 {
      font-size: 2em;
      color: #fff;
      text-align: center;
    }

    .inputbox {
      position: relative;
      margin: 30px 0;
      width: 310px;
      border-bottom: 2px solid #fff;
    }

    .inputbox label {
      position: absolute;
      top: 50%;
      left: 5px;
      transform: translateY(-50%);
      color: #fff;
      font-size: 1em;
      transition: 0.5s;
      pointer-events: none;
    }

    .inputbox input {
      width: 100%;
      height: 50px;
      background: transparent;
      border: none;
      outline: none;
      font-size: 1em;
      padding: 0 35px 0 5px;
      color: #fff;
    }

    input:focus ~ label,
    input:valid ~ label {
      top: -5px;
    }

    .inputbox ion-icon {
      position: absolute;
      right: 8px;
      top: 20px;
      color: #fff;
      font-size: 1.2em;
    }

    button {
      width: 100%;
      height: 40px;
      border-radius: 40px;
      background: #fff;
      border: none;
      cursor: pointer;
      font-size: 1em;
      font-weight: 600;
      margin-top: 10px;
    }

    .register {
      font-size: 0.9em;
      color: #fff;
      text-align: center;
      margin: 20px 0 10px;
    }

    .register a {
      color: #fff;
      text-decoration: underline;
      cursor: pointer;
    }

    .flip-card-back {
      transform: rotateY(180deg);
    }
  </style>
</head>
<body>
  <section>
    <div class="flip-card">
      <div class="flip-card-inner" id="flipCard">
        <!-- Login Side -->
        <div class="flip-card-front">
          <div class="form-box">
            <h2>Login</h2>
            <form method="POST">
              <div class="inputbox">
                <ion-icon name="person-outline"></ion-icon>
                <input name='userName' type="text" required>
                <label>Username</label>
              </div>
              <div class="inputbox">
                <ion-icon name="lock-closed-outline"></ion-icon>
                <input name='password' type="password" required>
                <label>Password</label>
              </div>
              <button name="logInBtn">Log in</button>
              <div class="register">
                <p>Forgot your password?
                  <a href="forgetpassword.php" style="text-decoration:underline; color:#fff;">Reset here</a>
                </p>
                <p>Don't have an account? <a onclick="flip()">Register</a></p>
              </div>
            </form>
          </div>
        </div>

        <!-- Sign-up Side -->
        <div class="flip-card-back">
          <div class="form-box">
            <h2>Sign Up</h2>
            <?php if (!empty($signup_error)): ?>
             <p style="color: red; text-align:center;"><?php echo $signup_error; ?></p>
            <?php endif; ?>

            <form method="POST">
              <div class="inputbox">
              <ion-icon name="person-outline"></ion-icon>
              <input name='newUser' type="text" required>
              <label>Username</label>
              </div>

              <div class="inputbox">
              <ion-icon name="person-outline"></ion-icon>
              <input name='firstName' type="text" required>
              <label>First Name</label>
              </div>

              <div class="inputbox">
              <ion-icon name="person-outline"></ion-icon>
              <input name='lastName' type="text" required>
              <label>Last Name</label>
              </div>

              <div class="inputbox">
              <ion-icon name="mail-outline"></ion-icon>
              <input name='email' type="email" required>
              <label>Email</label>
              </div>

              <div class="inputbox">
              <ion-icon name="lock-closed-outline"></ion-icon>
              <input name='newPassword' type="password" required>
              <label>Password</label>
              </div>

              <div class="inputbox">
              <ion-icon name="lock-closed-outline"></ion-icon>
              <input name='confirmPassword' type="password" required>
              <label>Confirm Password</label>
              </div>

             <button name="signUpBtn">Sign Up</button>
             <div class="register">
              <p>Already have an account? <a onclick="flip()">Login</a></p>
             </div>
          </form>
         </div>
        </div>
      </div>
    </div>
  </section>


  <script src='https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js'></script>
  <script>
    function flip() {
      document.getElementById('flipCard').classList.toggle('flipped');
    }
  </script>
</body>
</html>
