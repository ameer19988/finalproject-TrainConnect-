<?php
include 'navbar.php';
include_once 'db_connection.php';
$con = OpenCon();

if (!isset($_SESSION['logged_in_user'])) {
    echo "<div class='info-message'>You must be logged in to view your programs.</div>";
    exit();
}

$username = $_SESSION['logged_in_user'];

// Get user ID
$user_result = mysqli_query($con, "SELECT id FROM users WHERE username = '$username'");
if (!$user_result || mysqli_num_rows($user_result) == 0) {
    echo "<div class='info-message'>User not found.</div>";
    exit();
}
$user_row = mysqli_fetch_assoc($user_result);
$user_id = (int)$user_row['id'];

/* ---------- Handle ONE review per trainer (no per-order reviews) ---------- */
$flash = '';
if (isset($_POST['submit_review'])) {
    $trainer_id = isset($_POST['trainer_id']) ? (int)$_POST['trainer_id'] : 0;
    $review_txt = isset($_POST['review_text']) ? trim($_POST['review_text']) : '';

    if ($trainer_id > 0 && $review_txt !== '') {
        // Already reviewed this trainer?
        $already = mysqli_query($con, "SELECT id FROM reviews WHERE trainer_id = $trainer_id AND user_id = $user_id");
        if ($already && mysqli_num_rows($already) > 0) {
            $flash = "<div class='info-message' style='color:#b45d00;'>You already submitted a review for this trainer.</div>";
        } else {
            $safe_text = mysqli_real_escape_string($con, $review_txt);
            $ins = mysqli_query($con, "INSERT INTO reviews (user_id, trainer_id, review_text) VALUES ($user_id, $trainer_id, '$safe_text')");
            if ($ins) {
                $flash = "<div class='info-message' style='color:green;'>Thanks! Your review was submitted.</div>";
            } else {
                $flash = "<div class='info-message' style='color:red;'>Could not save your review. Please try again.</div>";
            }
        }
    } else {
        $flash = "<div class='info-message' style='color:red;'>Please write something before submitting your review.</div>";
    }
}

/* ---------- Get completed orders (include program_end_date) ---------- */
$orders = mysqli_query($con, "
  SELECT id, trainer_id, order_date, package_type, meeting_day, meeting_time, program_end_date
  FROM trainer_orders
  WHERE user_id = $user_id AND is_completed = 1
  ORDER BY order_date DESC
");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>My Programs</title>
  <style>
  body { font-family: Arial, sans-serif; margin: 0; padding: 0; color: #f5f6f8; background: url('images/back.jpg') center/cover fixed no-repeat; }
.container { max-width: 1350px; margin: 30px auto; background: rgba(0,0,0,.55); backdrop-filter: blur(8px); -webkit-backdrop-filter: blur(8px); padding: 20px; border-radius: 10px; box-shadow: 0 0 10px rgba(0,0,0,.4); border: 1px solid rgba(255,255,255,.18); }
h2 { text-align: center; color: #ffe08a; margin-top: 0; }
table { width: 100%; border-collapse: collapse; }
th, td { padding: 10px 8px; border-bottom: 1px solid rgba(255,255,255,.15); text-align: left; vertical-align: top; }
th { background: rgba(255,255,255,.08); color: #fff; }
th:last-child, td:last-child { width: 420px; }
.muted { color: #cfd2d8; font-size: 12px; }
.pkg { display: inline-block; padding: 2px 10px; border-radius: 12px; font-size: 12px; }
.pkg-regular { background: rgba(64,164,255,.18); color: #e8f3ff; }
.pkg-premium { background: rgba(255,193,7,.18); color: #fff5da; }
a.btn { text-decoration: none; background: #ff8c3a; color: #fff; padding: 6px 12px; border-radius: 6px; }
a.btn:hover { background: #e77a2f; }
.btn-small { background: #ff8c3a; color: #fff; border: none; border-radius: 6px; padding: 6px 10px; cursor: pointer; }
.btn-small:hover { background: #e77a2f; }
td > div[style*="white-space:pre-wrap"] { background: rgba(255,255,255,.08); color: #fff !important; border: 1px solid rgba(255,255,255,.25) !important; border-radius: 7px; }
.review-text { width: 100%; min-height: 110px; padding: 10px; border: 1px solid rgba(255,255,255,.22); border-radius: 6px; box-sizing: border-box; resize: vertical; background: rgba(255,255,255,.08); color: #fff; }
.info-message { text-align: center; background: rgba(255,255,255,.08); border: 1px solid rgba(255,255,255,.25); border-radius: 7px; padding: 10px; margin: 10px 0; color: #ffe08a; }

  </style>
</head>
<body>
<div class="container">
  <h2>My Training Programs</h2>

  <?php if (!empty($flash)) echo $flash; ?>

  <?php if ($orders && mysqli_num_rows($orders) > 0): ?>
    <table>
      <tr>
        <th style="width:180px;">Program</th>
        <th style="width:180px;">Trainer</th>
        <th style="width:150px;">Category</th>
        <th style="width:160px;">Weekly Call</th>
        <th style="width:120px;">View</th>
        <th style="width:140px;">Message</th>
        <th>Review</th>
      </tr>
      <?php while ($o = mysqli_fetch_assoc($orders)): ?>
        <?php
          $order_id = (int)$o['id'];
          $trainer_name = '—';
          $category_name = '—';

          $tid = (int)$o['trainer_id'];
          $tres = mysqli_query($con, "SELECT name, category_id FROM trainers WHERE id = $tid");
          if ($tres && $trow = mysqli_fetch_assoc($tres)) {
              $trainer_name = $trow['name'];
              $cat_id = (int)$trow['category_id'];
              if ($cat_id > 0) {
                  $cres = mysqli_query($con, "SELECT name FROM categories_new WHERE id = $cat_id");
                  if ($cres && $crow = mysqli_fetch_assoc($cres)) {
                      $category_name = $crow['name'];
                  }
              }
          }

          $pkg = ucfirst($o['package_type']);
          $pkgClass = (strtolower($o['package_type']) === 'premium') ? 'pkg-premium' : 'pkg-regular';
          $call = (!empty($o['meeting_day']) && !empty($o['meeting_time']))
                  ? ($o['meeting_day'] . ' ' . $o['meeting_time'])
                  : '<span class="muted">Not scheduled</span>';

          // Should we show the Message button? Hide on end-date and after.
          // date_default_timezone_set('Asia/Jerusalem'); // optional if your server TZ differs
          $end = isset($o['program_end_date']) ? $o['program_end_date'] : null;
          $todayTs = strtotime('today');
          $can_message = (empty($end) || (strtotime($end) > $todayTs)); // show only if future or NULL

          // Has the user already reviewed THIS trainer?
          $rev_exists_q = mysqli_query($con, "SELECT id, review_text, created_at FROM reviews WHERE trainer_id = $tid AND user_id = $user_id");
          $has_review = ($rev_exists_q && mysqli_num_rows($rev_exists_q) > 0);
          $review_text = '';
          $review_date = '';
          if ($has_review) {
              $rv = mysqli_fetch_assoc($rev_exists_q);
              $review_text = $rv['review_text'];
              $review_date = date('d M Y', strtotime($rv['created_at']));
          }
        ?>
        <tr>
          <td>
            <?php echo date('d M Y', strtotime($o['order_date'])); ?>
            <span class="pkg <?php echo $pkgClass; ?>"><?php echo $pkg; ?></span>
          </td>
          <td><?php echo htmlspecialchars($trainer_name); ?></td>
          <td><?php echo htmlspecialchars($category_name); ?></td>
          <td><?php echo $call; ?></td>
          <td><a class="btn" href="view_program.php?order_id=<?php echo $order_id; ?>">View</a></td>

          <td>
            <?php if ($can_message): ?>
              <a class="btn" href="messages.php?order_id=<?php echo $order_id; ?>">Message</a>
            <?php else: ?>
              <?php
                if (!empty($end) && strtotime($end) == $todayTs) {
                  echo '<span class="muted">Ends today</span>';
                } else {
                  echo '<span class="muted">Program finished</span>';
                }
              ?>
            <?php endif; ?>
          </td>

          <td>
            <?php if ($has_review): ?>
              <div style="font-size:13px; color:#333; white-space:pre-wrap; border:1px solid #e5e5e5; padding:8px; border-radius:6px;">
                <b>Your review (<?php echo $review_date; ?>):</b><br>
                <?php echo htmlspecialchars($review_text); ?>
              </div>
            <?php else: ?>
              <form method="post" style="margin:0;">
                <input type="hidden" name="trainer_id" value="<?php echo $tid; ?>">
                <textarea class="review-text" name="review_text" placeholder="Write your review about the trainer/program..."></textarea>
                <div style="margin-top:6px;">
                  <button class="btn-small" type="submit" name="submit_review">Send</button>
                </div>
              </form>
            <?php endif; ?>
          </td>
        </tr>
      <?php endwhile; ?>
    </table>
  <?php else: ?>
    <p style="text-align:center;">No completed programs found.</p>
  <?php endif; ?>
</div>
</body>
</html>
