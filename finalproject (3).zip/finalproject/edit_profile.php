<?php
session_start();
include_once 'db_connection.php';
include 'navbar.php';
$con = OpenCon();

if (!isset($_SESSION['logged_in_user'])) {
    header("Location: login.php");
    exit();
}

$username = $_SESSION['logged_in_user'];
$res = mysqli_query($con, "SELECT * FROM users WHERE username = '$username'");
$user = mysqli_fetch_assoc($res);
if (!$user) { echo "<div class='info-message'>User not found.</div>"; exit(); }

if (isset($_POST['saveProfile'])) {
    $firstName = $_POST['firstname'];
    $lastName = $_POST['lastname'];
    $password = $_POST['password'];
    $confirmPassword = $_POST['confirm_password'];

    if ($password != $confirmPassword) {
        $msg = "<div class='info-message' style='color:red;'>Passwords do not match.</div>";
    } else {
        // If password is empty, keep old password
        if (empty($password)) {
            $password = $user['password'];
        }
        $update = mysqli_query($con, "UPDATE users SET firstname='$firstName', lastname='$lastName', password='$password' WHERE username='$username'");
        if ($update) {
            // Update trainer name if this user is a trainer
            if (isset($_SESSION['is_trainer']) && $_SESSION['is_trainer'] == 1) {
                $fullname = $firstName . " " . $lastName;
                // Get user id
                $user_id = $user['id'];
                mysqli_query($con, "UPDATE trainers SET name='$fullname' WHERE user_id='$user_id'");
            }

            $msg = "<div class='info-message' style='color:green;'>Profile updated successfully.</div>";
            $res = mysqli_query($con, "SELECT * FROM users WHERE username = '$username'");
            $user = mysqli_fetch_assoc($res);
        } else {
            $msg = "<div class='info-message' style='color:red;'>Update failed. Please try again.</div>";
        }
    }
    
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Edit Profile</title>
<style>
body { font-family: Arial, sans-serif; margin: 0; padding: 0; background: url('images/back2.png') center/cover fixed no-repeat; color: #f5f6f8; }
.profile-container { max-width: 460px; margin: 60px auto; background: rgba(0,0,0,.55); backdrop-filter: blur(8px); -webkit-backdrop-filter: blur(8px); border-radius: 14px; box-shadow: 0 10px 30px rgba(0,0,0,.35); padding: 30px 26px; border: 1px solid rgba(255,255,255,.18); }
h2 { margin: 0 0 20px; color: #ffe08a; text-align: center; }
.form-label { display: block; margin-bottom: 6px; color: #e6e7ea; font-size: 1em; font-weight: 700; }
.form-input { width: 100%; padding: 9px 10px; margin-bottom: 16px; border-radius: 7px; border: 1px solid rgba(255,255,255,.25); font-size: 1em; box-sizing: border-box; background: rgba(255,255,255,.08); color: #fff; transition: border 0.2s, background 0.2s; }
.form-input:focus { border: 1.5px solid #ffe08a; background: rgba(0,0,0,.4); outline: none; }
.info-message { text-align: center; background: rgba(255,255,255,.08); border: 1px solid rgba(255,255,255,.25); border-radius: 10px; padding: 11px; margin-bottom: 20px; color: #ffe08a; }
.submit-btn { width: 100%; background: #ff8c3a; color: #fff; border: none; border-radius: 30px; padding: 12px 0; font-size: 1.08em; font-weight: 700; cursor: pointer; margin-top: 8px; box-shadow: 0 8px 20px rgba(0,0,0,.3); transition: background 0.17s, transform 0.15s; }
.submit-btn:hover { background: #e77a2f; transform: translateY(-2px); }

</style>
</head>
<body>
<div class="profile-container">
  <h2>Edit Profile</h2>
  <?php if (isset($msg)) echo $msg; ?>
  <form method="post">
    <label class="form-label">First Name:</label>
    <input class="form-input" name="firstname" type="text" value="<?php echo htmlspecialchars($user['firstname']); ?>" required>

    <label class="form-label">Last Name:</label>
    <input class="form-input" name="lastname" type="text" value="<?php echo htmlspecialchars($user['lastname']); ?>" required>

    <label class="form-label">New Password:</label>
    <input class="form-input" name="password" type="password" placeholder="Leave blank to keep current password">

    <label class="form-label">Confirm Password:</label>
    <input class="form-input" name="confirm_password" type="password" placeholder="Confirm your password">

    <button class="submit-btn" name="saveProfile">Save Changes</button>
  </form>
</div>
</body>
</html>
