<?php
session_start();
include_once 'db_connection.php';
include 'navbar.php';
$con = OpenCon();

if (!isset($_SESSION['logged_in_user']) || !isset($_SESSION['is_trainer']) || $_SESSION['is_trainer'] != 1) {
    header("Location: login.php");
    exit();
}

$username = $_SESSION['logged_in_user'];
// Get user ID
$user_res = mysqli_query($con, "SELECT id FROM users WHERE username = '$username'");
$user_row = mysqli_fetch_assoc($user_res);
$user_id = $user_row['id'];

// Get trainer ID
$trainer_res = mysqli_query($con, "SELECT id FROM trainers WHERE user_id = '$user_id'");
$trainer_row = mysqli_fetch_assoc($trainer_res);
if (!$trainer_row) { echo "<div class='info-message'>Not a trainer.</div>"; exit(); }
$trainer_id = $trainer_row['id'];

// Get all orders for this trainer (that are not completed)
$orders_q = mysqli_query($con, "SELECT * FROM trainer_orders WHERE trainer_id = $trainer_id AND is_completed = 0");

$programs = [];
while ($order = mysqli_fetch_assoc($orders_q)) {
    // Get client info
    $client_q = mysqli_query($con, "SELECT firstname, lastname FROM users WHERE id = {$order['user_id']}");
    $client = mysqli_fetch_assoc($client_q);

    // Calculate deadline and days left
    $order_date = $order['order_date'];
    $package_type = $order['package_type'];
    $days_to_finish = ($package_type === 'regular') ? 3 : 1;
    $deadline = date('Y-m-d', strtotime("$order_date +$days_to_finish days"));
    $days_left = (strtotime($deadline) - strtotime(date('Y-m-d'))) / (60*60*24);
    $days_left = ceil($days_left);

    $programs[] = [
        'order_id' => $order['id'],
        'client_name' => $client['firstname'] . " " . $client['lastname'],
        'package_type' => ucfirst($package_type),
        'order_date' => $order_date,
        'deadline' => $deadline,
        'days_left' => $days_left
    ];
}

// Sort by days_left ASC (soonest deadline first)
usort($programs, function($a, $b) {
    return $a['days_left'] <=> $b['days_left'];
});
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Trainer Programs</title>
<style>
body { font-family: Arial, sans-serif; margin: 0; padding: 0; background: url('images/back.jpg') center/cover fixed no-repeat; color: #f5f6f8; }
.container { max-width: 900px; margin: 40px auto; background: rgba(0,0,0,.55); backdrop-filter: blur(8px); -webkit-backdrop-filter: blur(8px); border-radius: 16px; box-shadow: 0 10px 30px rgba(0,0,0,.35); padding: 28px; border: 1px solid rgba(255,255,255,.18); }
h2 { margin-bottom: 20px; color: #ffe08a; }
.table { width: 100%; border-collapse: collapse; color: #fff; }
.table th, .table td { border-bottom: 1px solid rgba(255,255,255,.15); padding: 10px 8px; text-align: left; }
.table th { background: rgba(255,255,255,.08); color: #ffd86e; }
.btn { background: #ff8c3a; color: #fff; border: none; border-radius: 20px; padding: 7px 20px; font-size: 1em; cursor: pointer; transition: background 0.17s, transform 0.15s; text-decoration: none; box-shadow: 0 4px 12px rgba(0,0,0,.3); }
.btn:hover { background: #e77a2f; transform: translateY(-2px); }
.status { display: inline-block; padding: 2px 12px; border-radius: 16px; font-size: 0.97em; }
.regular { background: rgba(64,164,255,.15); color: #40a4ff; border: 1px solid rgba(64,164,255,.4); }
.premium { background: rgba(255,193,7,.15); color: #ffc107; border: 1px solid rgba(255,193,7,.4); }
.danger { color: #ff6b6b; font-weight: bold; }

</style>
</head>
<body>
<div class="container">
  <h2>Your Active Programs</h2>
  <?php if (empty($programs)): ?>
    <p style="color:#888;">No active programs at the moment.</p>
  <?php else: ?>
    <table class="table">
      <tr>
        <th>#</th>
        <th>Client Name</th>
        <th>Type</th>
        <th>Order Date</th>
        <th>Deadline</th>
        <th>Days Left</th>
        <th>Action</th>
      </tr>
      <?php foreach($programs as $i => $p): ?>
        <tr>
          <td><?php echo $i+1; ?></td>
          <td><?php echo htmlspecialchars($p['client_name']); ?></td>
          <td>
            <span class="status <?php echo strtolower($p['package_type']); ?>">
              <?php echo $p['package_type']; ?>
            </span>
          </td>
          <td><?php echo $p['order_date']; ?></td>
          <td><?php echo $p['deadline']; ?></td>
          <td>
            <?php
              if ($p['days_left'] < 0) {
                echo "<span class='danger'>Expired!</span>";
              } elseif ($p['days_left'] == 0) {
                echo "<span class='danger'>Last Day!</span>";
              } else {
                echo $p['days_left'] . " days";
              }
            ?>
          </td>
          <td>
            <a href="work_program.php?order_id=<?php echo $p['order_id']; ?>" class="btn">Work on Program</a>
          </td>
        </tr>
      <?php endforeach; ?>
    </table>
  <?php endif; ?>
</div>
</body>
</html>
