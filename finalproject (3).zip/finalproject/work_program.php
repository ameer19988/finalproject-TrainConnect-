<?php
include 'navbar.php';
include_once 'db_connection.php';
include_once 'rating_helpers.php'; // recalc_trainer_rating($con, $trainer_id)
$con = OpenCon();

if (!isset($_GET['order_id'])) {
    echo "<div class='info-message'>No order selected.</div>";
    exit();
}

$order_id = (int) $_GET['order_id'];

/* -------- fetch order + client info -------- */
$order_q = mysqli_query($con, "SELECT * FROM trainer_orders WHERE id = $order_id");
if (!$order_q || mysqli_num_rows($order_q) === 0) {
    echo "<div class='info-message'>Order not found.</div>";
    exit();
}
$order = mysqli_fetch_assoc($order_q);

/* Guard: if already completed, don’t allow saving again */
if ((int)$order['is_completed'] === 1) {
    echo "<div class='info-message' style='text-align:center;color:#b00;'>This program was already completed.</div>";
    exit();
}

$trainer_id = (int)$order['trainer_id'];

$client_name = "Client";
$u_q = mysqli_query($con, "SELECT firstname, lastname FROM users WHERE id = {$order['user_id']}");
if ($u_q && mysqli_num_rows($u_q) > 0) {
    $u = mysqli_fetch_assoc($u_q);
    $client_name = trim($u['firstname'] . " " . $u['lastname']);
}

/* -------- helpers to repopulate fields -------- */
function posted($name) { return isset($_POST[$name]) ? $_POST[$name] : ''; }

/* -------- messages for calculators -------- */
$bmr_msg = "";
$bmi_msg = "";

/* -------- handle POST -------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Save program -> write to DB and mark completed + set end date
    if (isset($_POST['save_program'])) {
        // date_default_timezone_set('Asia/Jerusalem'); // optional

        /* === one-time point award on save (simple) === */
        $package_type = strtolower($order['package_type']); // 'regular' | 'premium'
        $todayMidnight = strtotime('today'); // 00:00 local
        $orderDayTs    = strtotime(date('Y-m-d', strtotime($order['order_date'])));
        $days_since    = (int)floor(($todayMidnight - $orderDayTs) / 86400);

        $isLate = ($package_type === 'premium') ? ($days_since > 1) : ($days_since > 3);
        if ($isLate) {
            mysqli_query($con, "UPDATE trainers SET delay_points = delay_points + 1 WHERE id = $trainer_id");
        }
        /* === END one-time point award === */

        // Save the 4 weeks
        for ($week = 1; $week <= 4; $week++) {
            $sun = mysqli_real_escape_string($con, $_POST["week{$week}_sun"] ?? '');
            $mon = mysqli_real_escape_string($con, $_POST["week{$week}_mon"] ?? '');
            $tue = mysqli_real_escape_string($con, $_POST["week{$week}_tue"] ?? '');
            $wed = mysqli_real_escape_string($con, $_POST["week{$week}_wed"] ?? '');
            $thu = mysqli_real_escape_string($con, $_POST["week{$week}_thu"] ?? '');
            $fri = mysqli_real_escape_string($con, $_POST["week{$week}_fri"] ?? '');
            $sat = mysqli_real_escape_string($con, $_POST["week{$week}_sat"] ?? '');

            mysqli_query(
                $con,
                "INSERT INTO work_programs (order_id, week, sunday, monday, tuesday, wednesday, thursday, friday, saturday)
                 VALUES ($order_id, $week, '$sun', '$mon', '$tue', '$wed', '$thu', '$fri', '$sat')"
            );
        }

        // program ends = the day the trainer saved + 28 days (4 weeks)
        $end_date = date('Y-m-d', strtotime('+28 days'));

        // mark order completed and store end date
        mysqli_query($con, "
            UPDATE trainer_orders
            SET is_completed = 1,
                program_end_date = '$end_date'
            WHERE id = $order_id
        ");

        // >>> Recompute trainer rating once (after possible delay_points change + completion)
        recalc_trainer_rating($con, $trainer_id);

        // Redirect to avoid resubmitting on refresh
        header("Location: trainer_programs.php?saved=1");
        exit();
    }

    // Calculator submits -> compute only, do NOT save or clear form
    if (isset($_POST['calc_bmr'])) {
        $w = floatval($order['weight']);   // kg
        $h = floatval($order['height']);   // cm
        $a = intval($order['age']);
        $g = strtolower(trim($order['gender']));

        $s = ($g === 'male') ? 5 : (($g === 'female') ? -161 : 0);
        $bmr = 10*$w + 6.25*$h - 5*$a + $s;

        $sedentary  = round($bmr * 1.20);
        $light      = round($bmr * 1.375);
        $moderate   = round($bmr * 1.55);
        $active     = round($bmr * 1.725);

        $bmr_msg = "<div class='calc-box'>
            <div class='calc-title'>Maintenance Calories (Estimates)</div>
            <div><b>BMR:</b> ".round($bmr)." kcal/day</div>
            <ul>
              <li>Sedentary (×1.20): <b>{$sedentary}</b> kcal</li>
              <li>Light (×1.375): <b>{$light}</b> kcal</li>
              <li>Moderate (×1.55): <b>{$moderate}</b> kcal</li>
              <li>Active (×1.725): <b>{$active}</b> kcal</li>
            </ul>
            <small style='color:#666'>Tip: deficit ~300–500 kcal for fat loss, surplus ~200–300 for lean gain.</small>
        </div>";
    }

    if (isset($_POST['calc_bmi'])) {
        $w = floatval($order['weight']); // kg
        $h_m = floatval($order['height']) / 100.0; // m
        if ($h_m > 0) {
            $bmi = $w / ($h_m * $h_m);
            $bmiRound = round($bmi, 1);
            if ($bmi < 18.5)         { $cat = "Underweight"; }
            elseif ($bmi < 25)       { $cat = "Normal weight"; }
            elseif ($bmi < 30)       { $cat = "Overweight"; }
            else                     { $cat = "Obesity"; }

            $bmi_msg = "<div class='calc-box'>
                <div class='calc-title'>BMI</div>
                <div><b>{$bmiRound}</b> — {$cat}</div>
            </div>";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Fill Program Plan</title>
<style>
body { font-family: Arial, sans-serif; margin:0; padding:0; background: url('images/back.jpg') center/cover fixed no-repeat; color: #f5f6f8; }
.wrapper { max-width: 1100px; margin: 30px auto; display: grid; grid-template-columns: 320px 1fr; gap: 18px; }
.card { background: rgba(0,0,0,.55); backdrop-filter: blur(8px); -webkit-backdrop-filter: blur(8px); border-radius: 16px; box-shadow: 0 10px 30px rgba(0,0,0,.35); border: 1px solid rgba(255,255,255,.18); }
.sidebar { padding: 20px; }
.sidebar h3 { margin: 0 0 10px; color: #ffe08a; }
.kv { margin-bottom: 8px; color: #fff; }
.kv b { display: inline-block; width: 120px; color: #ffd86e; }
.photo { width: 100%; border-radius: 8px; object-fit: cover; margin: 10px 0 12px; max-height: 260px; border: 1px solid rgba(255,255,255,.2); }
.note-box { background: rgba(255,255,255,.08); border: 1px solid rgba(255,255,255,.15); padding: 10px 12px; border-radius: 8px; white-space: pre-wrap; color: #f5f6f8; }
.tools { margin-top: 14px; display: grid; gap: 10px; }
.tools button { width: 100%; background: #ff8c3a; color: #fff; border: none; border-radius: 8px; padding: 10px 12px; font-size: 14px; cursor: pointer; box-shadow: 0 4px 12px rgba(0,0,0,.3); }
.tools button:hover { background: #e77a2f; }
.calc-box { margin-top: 12px; background: rgba(255,255,255,.08); border: 1px solid rgba(255,255,255,.15); padding: 10px 12px; border-radius: 8px; color: #fff; }
.calc-title { font-weight: bold; margin-bottom: 6px; color: #ffd86e; }
.form-card { padding: 24px 24px 28px; color: #fff; }
h2 { margin: 0 0 12px; text-align: center; color: #ffe08a; }
.table-block { margin-bottom: 30px; }
table { width: 100%; border-collapse: collapse; color: #fff; }
td { padding: 8px; vertical-align: top; }
label { font-weight: bold; display: inline-block; margin-bottom: 6px; color: #ffd86e; }
textarea { width: 100%; height: 80px; padding: 10px; resize: vertical; border: 1px solid rgba(255,255,255,.2); border-radius: 5px; font-size: 1em; box-sizing: border-box; background: rgba(255,255,255,.08); color: #fff; }
button.save { background: #ff8c3a; color: #fff; padding: 12px 20px; border: none; border-radius: 8px; font-size: 1em; cursor: pointer; display: block; margin: 0 auto; box-shadow: 0 4px 12px rgba(0,0,0,.3); }
button.save:hover { background: #e77a2f; }
.week-title { margin: 22px 0 10px; font-size: 1.2em; color: #ffd86e; }
.badge { display:inline-block; padding:2px 8px; border-radius:12px; font-size:12px; background: rgba(255,255,255,.1); color:#ffe08a; }
.tip { font-size:12px; color:#ddd; text-align:center; margin-bottom:10px; }

</style>
</head>
<body>

<form method="POST">
  <div class="wrapper">
    <div class="card sidebar">
      <h3><?php echo htmlspecialchars($client_name); ?></h3>
      <div class="kv"><b>Package:</b> <?php echo ucfirst(htmlspecialchars($order['package_type'])); ?> <span class="badge">Order #<?php echo $order_id; ?></span></div>
      <div class="kv"><b>Ordered:</b> <?php echo date('d M Y', strtotime($order['order_date'])); ?></div>

      <hr style="border:none;height:1px;background:#eee;margin:12px 0;">

      <div class="kv"><b>Age:</b> <?php echo (int)$order['age']; ?></div>
      <div class="kv"><b>Height:</b> <?php echo (int)$order['height']; ?> cm</div>
      <div class="kv"><b>Weight:</b> <?php echo (int)$order['weight']; ?> kg</div>
      <div class="kv"><b>Gender:</b> <?php echo htmlspecialchars($order['gender']); ?></div>

      <?php if (!empty($order['meeting_day']) || !empty($order['meeting_time'])): ?>
        <div class="kv"><b>Weekly call:</b> <?php echo htmlspecialchars($order['meeting_day'] . ' ' . $order['meeting_time']); ?></div>
      <?php endif; ?>

      <?php if (!empty($order['photo'])): ?>
        <img class="photo" src="<?php echo htmlspecialchars($order['photo']); ?>" alt="Client photo">
      <?php endif; ?>

      <?php if (!empty($order['notes'])): ?>
        <div class="kv"><b>Notes:</b></div>
        <div class="note-box"><?php echo htmlspecialchars($order['notes']); ?></div>
      <?php endif; ?>

      <div class="tools">
        <button type="submit" name="calc_bmr">Calculate Maintenance Calories</button>
        <button type="submit" name="calc_bmi">Calculate BMI</button>
        <?php
          if (!empty($bmr_msg)) echo $bmr_msg;
          if (!empty($bmi_msg)) echo $bmi_msg;
        ?>
      </div>
    </div>

    <div class="card form-card">
      <h2>Fill Program Plan - Order #<?php echo $order_id; ?></h2>
      <div class="tip">Tip: The calculator buttons won’t save. Click “Save Program” at the bottom when you’re done.</div>

      <?php
      $days = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
      for ($week = 1; $week <= 4; $week++): ?>
        <div class="week-title">Week <?php echo $week; ?></div>
        <div class="table-block">
          <table>
            <?php foreach ($days as $day):
              $abbr = strtolower(substr($day, 0, 3));
              $input_name = "week{$week}_{$abbr}";
            ?>
              <tr>
                <td style="width: 120px;"><label><?php echo $day; ?></label></td>
                <td>
                  <textarea name="<?php echo $input_name; ?>"><?php echo htmlspecialchars(posted($input_name)); ?></textarea>
                </td>
              </tr>
            <?php endforeach; ?>
          </table>
        </div>
      <?php endfor; ?>

      <button class="save" type="submit" name="save_program">Save Program</button>
    </div>
  </div>
</form>

</body>
</html>
