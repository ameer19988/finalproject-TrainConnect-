<?php
include 'navbar.php';
include 'categories.php';
include_once 'db_connection.php';
$con = OpenCon();

/* ------- read filters (GET) ------- */
$category_id = isset($_GET['category_id']) ? (int)$_GET['category_id'] : 0;
$min_exp     = isset($_GET['min_exp']) ? (int)$_GET['min_exp'] : 0;
$sort        = isset($_GET['sort']) ? $_GET['sort'] : 'rating_desc';

$min_price   = isset($_GET['min_price']) ? trim($_GET['min_price']) : '';
$max_price   = isset($_GET['max_price']) ? trim($_GET['max_price']) : '';

/* ------- build query safely (no joins) ------- */
$where = [];
if ($category_id > 0) $where[] = "category_id = $category_id";
if ($min_exp > 0)     $where[] = "experience >= $min_exp";

$where_sql = (count($where) ? ('WHERE '.implode(' AND ', $where)) : '');

switch ($sort) {
  case 'exp_desc':  $order_sql = "ORDER BY rating DESC, experience DESC, name ASC"; break;
  case 'name_asc':  $order_sql = "ORDER BY name ASC"; break;
  case 'rating_desc':
  default:          $order_sql = "ORDER BY rating DESC, experience DESC, name ASC"; break;
}

$query  = "SELECT id, name, experience, age, rating, image FROM trainers $where_sql $order_sql";
$result = mysqli_query($con, $query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Trainers</title>
  <style>
body {
  font-family: Arial, Helvetica, sans-serif;
  margin: 0;
  padding: 20px;
  background: url('images/back.jpg') no-repeat center center fixed;
  background-size: cover;
  color: #fff;
}

h1 {
  text-align: center;
  margin: 14px 0 20px;
  color: #ffe680;
  text-shadow: 2px 2px 5px rgba(0, 0, 0, 0.7);
}

.filters {
  max-width: 1100px;
  margin: 0 auto 18px;
  background: rgba(0, 0, 0, 0.6);
  border-radius: 10px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.4);
  padding: 12px 14px;
  display: flex;
  gap: 10px;
  flex-wrap: wrap;
  align-items: end;
}

.filters .field label {
  font-size: 13px;
  color: #ffd966;
}

/* Styled select to match dark theme */
.filters select {
  background: rgba(255, 255, 255, 0.08);
  color: #fff;
  border: 1px solid #ffd966;
  border-radius: 8px;
  padding: 8px 10px;
  min-width: 140px;
  appearance: none;
  -webkit-appearance: none;
  -moz-appearance: none;
}

.filters select option {
  background: #1b1b1b;
  color: #fff;
}

.filters select:focus {
  outline: none;
  box-shadow: 0 0 0 2px rgba(255, 216, 110, 0.35);
  border-color: #ffd966;
}

.filters input {
  padding: 8px 10px;
  border: 1px solid #ffd966;
  border-radius: 8px;
  min-width: 140px;
  background: rgba(255, 255, 255, 0.1);
  color: #fff;
}

.filters input::placeholder {
  color: #ccc;
}

.filters .btn {
  background: #ff9933;
  color: #fff;
  border: none;
  padding: 9px 14px;
  border-radius: 8px;
  cursor: pointer;
  font-weight: bold;
}

.filters .btn:hover {
  background: #e68a00;
}

.trainers-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 30px;
  justify-items: center;
  max-width: 1200px;
  margin: 0 auto;
}

.flip-card {
  background-color: transparent;
  width: 300px;
  height: 300px;
  perspective: 1000px;
}

.flip-card-inner {
  position: relative;
  width: 100%;
  height: 100%;
  text-align: center;
  transition: transform 0.6s;
  transform-style: preserve-3d;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.5);
  border-radius: 10px;
}

.flip-card:hover .flip-card-inner {
  transform: rotateY(180deg);
}

.flip-card-front,
.flip-card-back {
  position: absolute;
  width: 100%;
  height: 100%;
  -webkit-backface-visibility: hidden;
  backface-visibility: hidden;
  border-radius: 10px;
}

.flip-card-front {
  background-color: rgba(255, 255, 255, 0.1);
}

.flip-card-front img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  border-radius: 10px;
}

.flip-card-back {
  background: linear-gradient(135deg, #ff9933, #cc6600);
  color: white;
  transform: rotateY(180deg);
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  padding: 10px;
}

.profile-btn {
  color: white;
  background: #ff6600;
  padding: 7px 14px;
  border-radius: 7px;
  text-decoration: none;
  display: inline-block;
  margin-top: 10px;
  font-weight: 500;
  transition: background 0.2s;
}

.profile-btn:hover {
  background: #e65c00;
}

.muted {
  color: #ddd;
  font-size: 12px;
}

  </style>
</head>
<body>

<h1>Our Trainers</h1>

<!-- Filters bar -->
<form class="filters" method="get" action="trainers.php">
  <div class="field">
    <label>Category</label>
    <select name="category_id" onchange="this.form.submit()">
      <option value="0">All</option>
      <?php
      $catRes = mysqli_query($con, "SELECT id, name FROM categories_new ORDER BY name ASC");
      if ($catRes) {
        while ($c = mysqli_fetch_assoc($catRes)) {
          $sel = ($category_id == (int)$c['id']) ? 'selected' : '';
          echo '<option value="'.$c['id'].'" '.$sel.'>'.htmlspecialchars($c['name']).'</option>';
        }
      }
      ?>
    </select>
  </div>

  <div class="field">
    <label>Min Experience (years)</label>
    <input type="number" min="0" name="min_exp" value="<?php echo (int)$min_exp; ?>">
  </div>

  <div class="field">
    <label>Sort</label>
    <select name="sort">
      <option value="rating_desc" <?php echo ($sort==='rating_desc'?'selected':''); ?>>Highest rating</option>
      <option value="exp_desc"   <?php echo ($sort==='exp_desc'  ?'selected':''); ?>>Most experience</option>
      <option value="name_asc"   <?php echo ($sort==='name_asc'  ?'selected':''); ?>>Name (A–Z)</option>
    </select>
  </div>

  <div class="field">
    <label>Min Price (optional)</label>
    <input type="number" min="0" name="min_price" value="<?php echo htmlspecialchars($min_price); ?>">
  </div>
  <div class="field">
    <label>Max Price (optional)</label>
    <input type="number" min="0" name="max_price" value="<?php echo htmlspecialchars($max_price); ?>">
  </div>

  <button class="btn" type="submit">Apply</button>
  <div class="muted">* Price filter will work once we wire it to your prices table.</div>
</form>

<div class="trainers-grid">
<?php
if ($result && mysqli_num_rows($result) > 0) {
  while ($row = mysqli_fetch_assoc($result)) {
    $name = $row['name'];
    $experience = (int)$row['experience'];
    $age = (int)$row['age'];
    $rating = (int)$row['rating'];
    $image = $row['image'];

    echo "
      <div class='flip-card'>
        <div class='flip-card-inner'>
          <div class='flip-card-front'>
            <img src='".htmlspecialchars($image)."' alt='".htmlspecialchars($name)."'>
          </div>
          <div class='flip-card-back'>
            <h2>".htmlspecialchars($name)."</h2>
            <p>Experience: {$experience} yrs</p>
            <p>Age: {$age}</p>
            <p>Rating: {$rating} ⭐</p>
            <a href='trainer_profile.php?id={$row['id']}' class='profile-btn'>View Profile</a>
          </div>
        </div>
      </div>
    ";
  }
} else {
  echo "<p class='muted' style='text-align:center;'>No trainers matched your filters.</p>";
}
?>
</div>

</body>
</html>
