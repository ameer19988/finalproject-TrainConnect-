<?php
// trainer_inbox.php
session_start();
include 'navbar.php';
include_once 'db_connection.php';
$con = OpenCon();

if (!isset($_SESSION['logged_in_user']) || !isset($_SESSION['is_trainer']) || $_SESSION['is_trainer'] != 1) {
    exit("Not allowed");
}

$username = $_SESSION['logged_in_user'];

/* get current trainer_id from username */
$resUser = mysqli_query($con, "SELECT id FROM users WHERE username='$username'");
if (!$resUser || mysqli_num_rows($resUser) == 0) exit("User not found");
$user_id = (int)mysqli_fetch_assoc($resUser)['id'];

$resTrainer = mysqli_query($con, "SELECT id FROM trainers WHERE user_id=$user_id");
if (!$resTrainer || mysqli_num_rows($resTrainer) == 0) exit("Not a trainer");
$trainer_id = (int)mysqli_fetch_assoc($resTrainer)['id'];

/* collect all order_ids that have messages for this trainer (completed or not) */
$order_ids_res = mysqli_query($con, "
  SELECT DISTINCT order_id
  FROM messages
  WHERE trainer_id = $trainer_id
  ORDER BY order_id DESC
");

$waiting = [];
if ($order_ids_res) {
    while ($ro = mysqli_fetch_assoc($order_ids_res)) {
        $order_id = (int)$ro['order_id'];

        // pull order info (need package + client for context)
        $oRes = mysqli_query($con, "SELECT user_id, package_type, is_completed FROM trainer_orders WHERE id=$order_id");
        if (!$oRes || mysqli_num_rows($oRes) == 0) continue;
        $o = mysqli_fetch_assoc($oRes);

        $package  = strtolower($o['package_type']);        // 'regular' / 'premium'
        $days_to_answer = ($package === 'premium') ? 1 : 3;

        // last client message
        $lastUser = mysqli_query($con, "
            SELECT message_text, created_at, reply_deadline
            FROM messages
            WHERE order_id=$order_id AND sender='user'
            ORDER BY created_at DESC
            LIMIT 1
        ");
        if (!$lastUser || mysqli_num_rows($lastUser) == 0) continue;
        $lu = mysqli_fetch_assoc($lastUser);

        // last trainer message
        $lastTrainer = mysqli_query($con, "
            SELECT created_at
            FROM messages
            WHERE order_id=$order_id AND sender='trainer'
            ORDER BY created_at DESC
            LIMIT 1
        ");

        $trainerReplied = false;
        if ($lastTrainer && mysqli_num_rows($lastTrainer) > 0) {
            $lt = mysqli_fetch_assoc($lastTrainer);
            // if trainer's last message is newer than client's last message -> already replied
            if (strtotime($lt['created_at']) > strtotime($lu['created_at'])) {
                $trainerReplied = true;
            }
        }

        // still awaiting reply
        if (!$trainerReplied) {
            // deadline might be null (safety). if null, derive from created_at + SLA
            $deadline_str = $lu['reply_deadline'];
            if (empty($deadline_str)) {
                $deadline_str = date('Y-m-d H:i:s', strtotime($lu['created_at'] . " +$days_to_answer days"));
            }
            $deadline_ts = strtotime($deadline_str);
            $now_ts = time();
            $time_left_days = ceil(($deadline_ts - $now_ts) / 86400);

            $waiting[] = [
                'order_id'    => $order_id,
                'client_id'   => (int)$o['user_id'],
                'package'     => ucfirst($package),
                'last_msg'    => $lu['message_text'],
                'deadline'    => $deadline_str,
                'time_left'   => $time_left_days,
                'is_completed'=> (int)$o['is_completed']
            ];
        }
    }
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Trainer Inbox</title>
<style>
body { font-family: Arial, sans-serif; margin:0; padding:0; background: url('images/back3.jpg') center/cover fixed no-repeat; color:#f5f6f8; }
.wrap { max-width:1000px; margin:40px auto; background:rgba(0,0,0,.55); backdrop-filter:blur(8px); -webkit-backdrop-filter:blur(8px); border-radius:16px; box-shadow:0 10px 30px rgba(0,0,0,.35); padding:28px; border:1px solid rgba(255,255,255,.18); }
h2 { margin:0 0 16px; color:#ffe08a; text-align:center; }
table { width:100%; border-collapse:collapse; color:#fff; }
th, td { padding:10px 8px; border-bottom:1px solid rgba(255,255,255,.15); text-align:left; vertical-align:top; }
th { background:rgba(255,255,255,.08); color:#ffd86e; font-weight:bold; }
.badge { display:inline-block; padding:3px 10px; border-radius:999px; font-size:12px; border:1px solid rgba(255,255,255,.18); }
.pkg-regular { background:rgba(64,164,255,.18); color:#e8f3ff; border-color:rgba(64,164,255,.35); }
.pkg-premium { background:rgba(255,140,58,.18); color:#ffe1c4; border-color:rgba(255,140,58,.4); }
.state-completed { background:rgba(46,204,113,.18); color:#d9f7e6; border-color:rgba(46,204,113,.4); }
.state-active { background:rgba(255,215,0,.15); color:#fff4c2; border-color:rgba(255,215,0,.35); }
.btn { background:#ff8c3a; color:#fff; padding:8px 14px; border:none; border-radius:8px; text-decoration:none; display:inline-block; box-shadow:0 4px 12px rgba(0,0,0,.3); transition:background .2s, transform .15s; }
.btn:hover { background:#e77a2f; transform:translateY(-1px); }
.late { color:#ff6b6b; font-weight:bold; }
p { color:#ddd; }

</style>
</head>
<body>
<div class="wrap">
  <h2>Messages Waiting for Your Reply</h2>

  <?php if (empty($waiting)): ?>
    <p style="color:#666;">No pending messages.</p>
  <?php else: ?>
    <table>
      <tr>
        <th>Order</th>
        <th>Package</th>
        <th>Status</th>
        <th>Last Client Message</th>
        <th>Deadline</th>
        <th>Time Left</th>
        <th>Action</th>
      </tr>
      <?php foreach ($waiting as $w): ?>
        <?php
          $pkgClass = (strtolower($w['package']) === 'premium') ? 'pkg-premium' : 'pkg-regular';
          $state = $w['is_completed'] ? '<span class="badge state-completed">Completed</span>'
                                      : '<span class="badge state-active">Active</span>';
        ?>
        <tr>
          <td>#<?php echo $w['order_id']; ?></td>
          <td><span class="badge <?php echo $pkgClass; ?>"><?php echo $w['package']; ?></span></td>
          <td><?php echo $state; ?></td>
          <td><?php echo htmlspecialchars($w['last_msg']); ?></td>
          <td><?php echo $w['deadline']; ?></td>
          <td>
            <?php
              if ($w['time_left'] < 0)      echo "<span class='late'>Expired!</span>";
              else if ($w['time_left'] == 0) echo "<span class='late'>Last Day!</span>";
              else                           echo $w['time_left'] . " day(s)";
            ?>
          </td>
          <td><a class="btn" href="messages.php?order_id=<?php echo $w['order_id']; ?>">Open Chat</a></td>
        </tr>
      <?php endforeach; ?>
    </table>
  <?php endif; ?>
</div>
</body>
</html>
