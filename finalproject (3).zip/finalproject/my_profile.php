<?php
session_start();
include_once 'db_connection.php';
include 'navbar.php';
$con = OpenCon();

if (!isset($_SESSION['logged_in_user'])) {
    header("Location: login.php");
    exit();
}

$username = $_SESSION['logged_in_user'];
$res = mysqli_query($con, "SELECT * FROM users WHERE username = '$username'");
$user = mysqli_fetch_assoc($res);
if (!$user) { echo "<div class='info-message'>User not found.</div>"; exit(); }
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>My Profile</title>
<style>
body { font-family: Arial, sans-serif; margin: 0; padding: 0; background: url('images/back2.png') center/cover fixed no-repeat; color: #f5f6f8; }
.profile-container { max-width: 460px; margin: 60px auto; background: rgba(0,0,0,.55); backdrop-filter: blur(8px); -webkit-backdrop-filter: blur(8px); border-radius: 14px; box-shadow: 0 10px 30px rgba(0,0,0,.35); padding: 30px 26px; border: 1px solid rgba(255,255,255,.18); }
h2 { margin: 0 0 20px; color: #ffe08a; text-align: center; }
.label { color: #e6e7ea; font-size: 1em; font-weight: 700; margin: 14px 0 4px; }
.value { margin: 0 0 10px; display: block; color: #fff; background: rgba(255,255,255,.08); border: 1px solid rgba(255,255,255,.22); border-radius: 10px; padding: 10px 12px; }
.edit-btn { display: block; margin: 22px auto 0; background: #ff8c3a; color: #fff; border: none; border-radius: 30px; padding: 10px 36px; font-size: 1em; font-weight: 700; text-decoration: none; text-align: center; box-shadow: 0 8px 20px rgba(0,0,0,.30); transition: transform .15s, background .15s; }
.edit-btn:hover { background: #e77a2f; transform: translateY(-2px); }
.info-message { text-align: center; background: rgba(255,255,255,.08); border: 1px solid rgba(255,255,255,.25); border-radius: 10px; padding: 11px; margin: 12px 0; color: #ffe08a; }

</style>
</head>
<body>
<div class="profile-container">
  <h2>My Profile</h2>
  <div class="label">Username:</div>
  <div class="value"><?php echo htmlspecialchars($user['username']); ?></div>
  <div class="label">Email:</div>
  <div class="value"><?php echo htmlspecialchars($user['email']); ?></div>
  <div class="label">First Name:</div>
  <div class="value"><?php echo htmlspecialchars($user['firstname']); ?></div>
  <div class="label">Last Name:</div>
  <div class="value"><?php echo htmlspecialchars($user['lastname']); ?></div>
  <a href="edit_profile.php" class="edit-btn">Edit Profile</a>
</div>
</body>
</html>
