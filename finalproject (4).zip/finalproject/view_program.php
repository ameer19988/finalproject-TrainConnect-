<?php
include 'navbar.php';
include_once 'db_connection.php';
$con = OpenCon();

if (!isset($_GET['order_id'])) {
    echo "<div class='info-message'>No program selected.</div>";
    exit();
}

$order_id = (int) $_GET['order_id'];
$result = mysqli_query($con, "SELECT * FROM work_programs WHERE order_id = $order_id ORDER BY week");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>View Program</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; padding: 0; background: url('images/back2.png') center/cover fixed no-repeat; color: #f5f6f8; }
.container { max-width: 900px; margin: 30px auto; background: rgba(0,0,0,.55); backdrop-filter: blur(8px); -webkit-backdrop-filter: blur(8px); padding: 30px; border-radius: 10px; box-shadow: 0 0 10px rgba(0,0,0,.4); border: 1px solid rgba(255,255,255,.18); }
h2 { text-align: center; color: #ffe08a; }
table { width: 100%; margin-bottom: 30px; border-collapse: collapse; }
td { padding: 10px; vertical-align: top; border-bottom: 1px solid rgba(255,255,255,.15); color: #fff; }
.week-title { margin: 30px 0 10px; font-size: 1.2em; font-weight: bold; color: #ff8c3a; }

    </style>
</head>
<body>
<div class="container">
    <h2>View Program - Order #<?php echo $order_id; ?></h2>

    <?php
    $days = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
    while ($row = mysqli_fetch_assoc($result)):
    ?>
        <div class="week-title">Week <?php echo $row['week']; ?></div>
        <table>
            <?php foreach ($days as $day): 
                $key = strtolower($day); ?>
                <tr>
                    <td style="width: 120px; font-weight: bold;"><?php echo $day; ?></td>
                    <td><?php echo nl2br(htmlspecialchars($row[$key])); ?></td>
                </tr>
            <?php endforeach; ?>
        </table>
    <?php endwhile; ?>
</div>
</body>
</html>
