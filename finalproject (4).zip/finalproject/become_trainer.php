<?php
session_start();
include_once 'db_connection.php';
include 'navbar.php';
$con = OpenCon();

if (!isset($_SESSION['logged_in_user'])) {
    header("Location: login.php");
    exit();
}

// Get all categories for the dropdown
$categories = [];
$res_cat = mysqli_query($con, "SELECT id, name FROM categories_new");
while ($row = mysqli_fetch_assoc($res_cat)) {
    $categories[] = $row;
}

if (isset($_POST['becomeTrainer'])) {
    $user = $_SESSION['logged_in_user'];
    $experience = $_POST['experience'];
    $age = $_POST['age'];
    $description = $_POST['description'];
    $category_id = (int)$_POST['category_id'];
    $regular_price = floatval($_POST['regular_price']);
    $premium_price = isset($_POST['premium_price']) && $_POST['premium_price'] !== '' ? floatval($_POST['premium_price']) : null;

    // --- Image upload (trainer photo) ---
    $image = "";
    if (isset($_FILES['image']) && $_FILES['image']['error'] === 0) {
        $imageName = $_FILES['image']['name'];
        $imageTmpName = $_FILES['image']['tmp_name'];
        $imageFolder = 'images/' . $imageName;
        if (move_uploaded_file($imageTmpName, $imageFolder)) {
            $image = $imageFolder;
        } else {
            echo "<div class='info-message'>Failed to upload profile photo.</div>";
        }
    }

    // Get user id, firstname, lastname
    $res = mysqli_query($con, "SELECT id, firstname, lastname FROM users WHERE username = '$user'");
    $user_row = mysqli_fetch_assoc($res);
    $user_id = $user_row['id'];
    $firstname = $user_row['firstname'];
    $lastname = $user_row['lastname'];
    $fullname = $firstname . " " . $lastname;

    // Check if already a trainer
    $check = mysqli_query($con, "SELECT * FROM trainers WHERE user_id = '$user_id'");
    if (mysqli_num_rows($check) == 0 && $image !== "") {
        // Insert trainer
        $query = "INSERT INTO trainers (user_id, name, experience, age, description, image, category_id)
                  VALUES ('$user_id', '$fullname', '$experience', '$age', '$description', '$image', '$category_id')";
        mysqli_query($con, $query);

        // Get new trainer id
        $trainer_id = mysqli_insert_id($con);

        // Insert package prices
        mysqli_query($con, "INSERT INTO packages (trainer_id, type, price) VALUES ($trainer_id, 'regular', $regular_price)");
        if ($premium_price !== null && $premium_price > 0) {
            mysqli_query($con, "INSERT INTO packages (trainer_id, type, price) VALUES ($trainer_id, 'premium', $premium_price)");
        }

        // Insert up to 4 results images
        if (isset($_FILES['results'])) {
            for ($i = 0; $i < 4; $i++) {
                if (isset($_FILES['results']['name'][$i]) && $_FILES['results']['name'][$i] != '' && $_FILES['results']['error'][$i] === 0) {
                    $resultImgName = $_FILES['results']['name'][$i];
                    $resultTmpName = $_FILES['results']['tmp_name'][$i];
                    $resultFolder = 'images/' . $resultImgName;
                    if (move_uploaded_file($resultTmpName, $resultFolder)) {
                        mysqli_query($con, "INSERT INTO trainer_results (trainer_id, image) VALUES ($trainer_id, '$resultFolder')");
                    }
                }
            }
        }

        mysqli_query($con, "UPDATE users SET trainer = 1 WHERE id = '$user_id'");
        $_SESSION['is_trainer'] = 1;
        header("Location: my_trainer_profile.php");
        exit();
    } elseif ($image !== "") {
        echo "<div class='info-message'>You are already a trainer!</div>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Become a Trainer</title>
  <style>
   body { font-family: Arial, sans-serif; margin: 0; padding: 0; background: url('images/back2.png') center/cover fixed no-repeat; color: #f5f6f8; min-height: 100vh; }
.trainer-form-container { max-width: 460px; margin: 60px auto 0; background: rgba(0,0,0,.55); backdrop-filter: blur(8px); -webkit-backdrop-filter: blur(8px); border-radius: 14px; box-shadow: 0 10px 30px rgba(0,0,0,.35); padding: 30px 26px 24px; border: 1px solid rgba(255,255,255,.18); }
.trainer-form-container h2 { text-align: center; margin: 0 0 18px; color: #ffe08a; font-size: 1.6em; }
.form-label { display: block; margin: 0 0 8px; color: #e8e9ec; font-size: 1em; }
.form-input, .form-textarea, .form-select { width: 100%; padding: 10px 12px; margin: 0 0 16px; border-radius: 10px; border: 1px solid rgba(255,255,255,.22); font-size: 1em; box-sizing: border-box; background: rgba(255,255,255,.08); color: #fff; transition: border .2s, background .2s; }
.form-input:focus, .form-textarea:focus, .form-select:focus { border: 1px solid #ff8c3a; background: rgba(255,255,255,.14); outline: none; }
.form-textarea { min-height: 60px; resize: vertical; }
.submit-btn { width: 100%; background: #ff8c3a; color: #fff; border: none; border-radius: 30px; padding: 12px 0; font-size: 1.08em; font-weight: 700; cursor: pointer; margin-top: 8px; box-shadow: 0 8px 20px rgba(0,0,0,.30); transition: transform .15s, background .15s; }
.submit-btn:hover { background: #e77a2f; transform: translateY(-2px); }
.info-message { text-align: center; color: #ffe08a; background: rgba(255,255,255,.08); border: 1px solid rgba(255,255,255,.25); border-radius: 10px; padding: 11px; margin-bottom: 20px; }
.note { font-size: .98em; color: #e6e7ea; margin: 0 0 10px; background: rgba(64,164,255,.18); padding: 8px 12px; border-radius: 10px; border: 1px solid rgba(64,164,255,.35); }

  </style>
</head>
<body>
  <div class="trainer-form-container">
    <h2>Become a Trainer</h2>
    <form method="post" enctype="multipart/form-data">
      <label class="form-label">Experience (years):</label>
      <input class="form-input" name="experience" type="number" min="0" max="70" required>
      
      <label class="form-label">Age:</label>
      <input class="form-input" name="age" type="number" min="16" max="99" required>
      
      <label class="form-label">Description:</label>
      <textarea class="form-textarea" name="description" placeholder="Tell us about your skills..."></textarea>
      
      <label class="form-label">Profile Photo:</label>
      <input class="form-input" name="image" type="file" accept="image/*" required>

      <label class="form-label">Category:</label>
      <select class="form-select" name="category_id" required>
        <option value="">Select category...</option>
        <?php foreach($categories as $cat): ?>
          <option value="<?php echo $cat['id']; ?>"><?php echo htmlspecialchars($cat['name']); ?></option>
        <?php endforeach; ?>
      </select>

      <label class="form-label">Regular Package Price (₪):</label>
      <input class="form-input" name="regular_price" type="number" step="0.01" min="0" required>
      <div class="note">
        <b>Regular Package:</b> Must finish the program in <b>3 days</b> and reply to clients within <b>3 days</b>.
      </div>

      <label class="form-label">Premium Package Price (₪): <small style="color:#888;">(optional)</small></label>
      <input class="form-input" name="premium_price" type="number" step="0.01" min="0">
      <div class="note">
        <b>Premium Package:</b> Must finish the program in <b>1 day</b> and reply to clients within <b>1 day</b>.
      </div>

      <label class="form-label">Upload Result Photos (up to 4):</label>
      <input class="form-input" name="results[]" type="file" accept="image/*">
      <input class="form-input" name="results[]" type="file" accept="image/*">
      <input class="form-input" name="results[]" type="file" accept="image/*">
      <input class="form-input" name="results[]" type="file" accept="image/*">

      <button class="submit-btn" name="becomeTrainer">Become Trainer</button>
    </form>
  </div>
</body>
</html>
