<?php
include 'db_connection.php';
$con = OpenCon();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Reset Password</title>
    <style>
        body {
            background: #f7f7f7;
            font-family: Arial, sans-serif;
            margin: 0;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .form-container {
            background: #fff;
            padding: 32px 30px;
            border-radius: 13px;
            box-shadow: 0 2px 10px #0002;
            width: 350px;
            text-align: center;
        }
        .form-container h2 {
            margin-bottom: 24px;
            color: #0066cc;
        }
        .form-container input, .form-container button {
            width: 100%;
            padding: 10px;
            margin-bottom: 16px;
            border: 1px solid #ccc;
            border-radius: 7px;
            font-size: 1em;
            box-sizing: border-box;
        }
        .form-container input:focus {
            border: 1.5px solid #0066cc;
            background: #f4faff;
            outline: none;
        }
        .form-container button {
            background-color: #0066cc;
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 30px;
            font-weight: 600;
            font-size: 1.08em;
            transition: background 0.17s;
        }
        .form-container button:hover {
            background-color: #004e99;
        }
        .error {
            color: #e74c3c;
            font-size: 1em;
            margin-bottom: 13px;
        }
        .info-msg {
            color: #0066cc;
            font-size: 1em;
            margin-bottom: 13px;
        }
    </style>
</head>
<body>
<div class="form-container">
    <h2>Reset Password</h2>
    <form method="POST">
        <?php
        if (isset($_POST['reset_password'])) {
            $email = trim($_POST['email']);
            $pass1 = $_POST['password1'];
            $pass2 = $_POST['password2'];

            $error_message = "";
            if (strlen($pass1) < 6) {
                $error_message = "Password must be at least 6 characters.";
            } elseif (!preg_match('/[A-Z]/', $pass1)) {
                $error_message = "Password must have at least one uppercase letter.";
            } elseif ($pass1 !== $pass2) {
                $error_message = "Passwords do not match.";
            } else {
                // Check for valid email with forget=1
                $res = mysqli_query($con, "SELECT * FROM users WHERE email='$email' AND forget=1");
                if ($row = mysqli_fetch_assoc($res)) {
                    // Update new password and reset forget/count
                    mysqli_query($con, "UPDATE users SET password='$pass1', forget=0, count=0 WHERE email='$email'");
                    echo "<div class='info-msg'>Password changed successfully! You can now <a href='login.php'>login</a>.</div>";
                } else {
                    $error_message = "You are not authorized to reset the password for this email. Please request a reset again.";
                }
            }
            if (!empty($error_message)) {
                echo "<div class='error'>$error_message</div>";
            }
        }
        ?>
        <label for="email">Email:</label>
        <input type="email" name="email" id="email" placeholder="Your email address" required>

        <label for="new_password">New Password:</label>
        <input type="password" name="password1" id="new_password" placeholder="Enter new password" required>

        <label for="confirm_password">Confirm Password:</label>
        <input type="password" name="password2" id="confirm_password" placeholder="Re-enter new password" required>

        <button type="submit" name="reset_password">Reset Password</button>
    </form>
</div>
</body>
</html>
