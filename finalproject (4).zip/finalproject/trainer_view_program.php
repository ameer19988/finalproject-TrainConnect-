<?php
include 'navbar.php';
include_once 'db_connection.php';
$con = OpenCon();

if (!isset($_GET['order_id'])) {
    echo "<div class='info-message'>No order selected.</div>";
    exit();
}

$order_id = (int) $_GET['order_id'];

// -------- fetch order + client info --------
$order_q = mysqli_query($con, "SELECT * FROM trainer_orders WHERE id = $order_id");
if (!$order_q || mysqli_num_rows($order_q) === 0) {
    echo "<div class='info-message'>Order not found.</div>";
    exit();
}
$order = mysqli_fetch_assoc($order_q);

$client_name = "Client";
$u_q = mysqli_query($con, "SELECT firstname, lastname FROM users WHERE id = {$order['user_id']}");
if ($u_q && mysqli_num_rows($u_q) > 0) {
    $u = mysqli_fetch_assoc($u_q);
    $client_name = trim($u['firstname'] . " " . $u['lastname']);
}

// -------- load existing program data --------
$program_data = [];
$res = mysqli_query($con, "SELECT * FROM work_programs WHERE order_id = $order_id");
while ($row = mysqli_fetch_assoc($res)) {
    $program_data[$row['week']] = $row;
}

// -------- handle POST (update) --------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_program'])) {
    for ($week = 1; $week <= 4; $week++) {
        $sun = mysqli_real_escape_string($con, $_POST["week{$week}_sun"]);
        $mon = mysqli_real_escape_string($con, $_POST["week{$week}_mon"]);
        $tue = mysqli_real_escape_string($con, $_POST["week{$week}_tue"]);
        $wed = mysqli_real_escape_string($con, $_POST["week{$week}_wed"]);
        $thu = mysqli_real_escape_string($con, $_POST["week{$week}_thu"]);
        $fri = mysqli_real_escape_string($con, $_POST["week{$week}_fri"]);
        $sat = mysqli_real_escape_string($con, $_POST["week{$week}_sat"]);

        // If row exists, update. If not, insert.
        $check = mysqli_query($con, "SELECT id FROM work_programs WHERE order_id = $order_id AND week = $week");
        if (mysqli_num_rows($check) > 0) {
            mysqli_query(
                $con,
                "UPDATE work_programs
                 SET sunday='$sun', monday='$mon', tuesday='$tue', wednesday='$wed',
                     thursday='$thu', friday='$fri', saturday='$sat'
                 WHERE order_id=$order_id AND week=$week"
            );
        } else {
            mysqli_query(
                $con,
                "INSERT INTO work_programs (order_id, week, sunday, monday, tuesday, wednesday, thursday, friday, saturday)
                 VALUES ('$order_id', '$week', '$sun', '$mon', '$tue', '$wed', '$thu', '$fri', '$sat')"
            );
        }
    }

    echo "<div class='info-message' style='color:green; text-align:center;'>Program updated successfully!</div>";
    // Reload program data after update
    $program_data = [];
    $res = mysqli_query($con, "SELECT * FROM work_programs WHERE order_id = $order_id");
    while ($row = mysqli_fetch_assoc($res)) {
        $program_data[$row['week']] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Edit Program Plan</title>
<style>
body { font-family: Arial, sans-serif; margin:0; padding:0; background: url('images/back3.jpg') center/cover fixed no-repeat; color: #f5f6f8; }
.wrapper { max-width: 1100px; margin: 30px auto; display: grid; grid-template-columns: 320px 1fr; gap: 18px; }
.card { background: rgba(0,0,0,.55); backdrop-filter: blur(8px); -webkit-backdrop-filter: blur(8px); border-radius: 16px; box-shadow: 0 10px 30px rgba(0,0,0,.35); border: 1px solid rgba(255,255,255,.18); }
.sidebar { padding: 20px; }
.sidebar h3 { margin: 0 0 10px; color: #ffe08a; }
.kv { margin-bottom: 8px; color: #fff; }
.kv b { display: inline-block; width: 120px; color: #ffd86e; }
.photo { width: 100%; border-radius: 8px; object-fit: cover; margin: 10px 0 12px; max-height: 260px; border: 1px solid rgba(255,255,255,.2); }
.note-box { background: rgba(255,255,255,.08); border: 1px solid rgba(255,255,255,.15); padding: 10px 12px; border-radius: 8px; white-space: pre-wrap; color: #f5f6f8; }
.tools { margin-top: 14px; display: grid; gap: 10px; }
.tools button { width: 100%; background: #ff8c3a; color: #fff; border: none; border-radius: 8px; padding: 10px 12px; font-size: 14px; cursor: pointer; box-shadow: 0 4px 12px rgba(0,0,0,.3); }
.tools button:hover { background: #e77a2f; }
.calc-box { margin-top: 12px; background: rgba(255,255,255,.08); border: 1px solid rgba(255,255,255,.15); padding: 10px 12px; border-radius: 8px; color: #fff; }
.calc-title { font-weight: bold; margin-bottom: 6px; color: #ffd86e; }
.form-card { padding: 24px 24px 28px; color: #fff; }
h2 { margin: 0 0 12px; text-align: center; color: #ffe08a; }
.table-block { margin-bottom: 30px; }
table { width: 100%; border-collapse: collapse; color: #fff; }
td { padding: 8px; vertical-align: top; }
label { font-weight: bold; display: inline-block; margin-bottom: 6px; color: #ffd86e; }
textarea { width: 100%; height: 80px; padding: 10px; resize: vertical; border: 1px solid rgba(255,255,255,.2); border-radius: 5px; font-size: 1em; box-sizing: border-box; background: rgba(255,255,255,.08); color: #fff; }
button.save { background: #ff8c3a; color: #fff; padding: 12px 20px; border: none; border-radius: 8px; font-size: 1em; cursor: pointer; display: block; margin: 0 auto; box-shadow: 0 4px 12px rgba(0,0,0,.3); }
button.save:hover { background: #e77a2f; }
.week-title { margin: 22px 0 10px; font-size: 1.2em; color: #ffd86e; }
.badge { display:inline-block; padding:2px 8px; border-radius:12px; font-size:12px; background: rgba(255,255,255,.1); color:#ffe08a; }
.tip { font-size:12px; color:#ddd; text-align:center; margin-bottom:10px; }

</style>
</head>
<body>

<form method="POST">
  <div class="wrapper">
    <!-- Sidebar -->
    <div class="card sidebar">
      <h3><?php echo htmlspecialchars($client_name); ?></h3>
      <div class="kv"><b>Package:</b> <?php echo ucfirst(htmlspecialchars($order['package_type'])); ?></div>
      <div class="kv"><b>Ordered:</b> <?php echo date('d M Y', strtotime($order['order_date'])); ?></div>
      <div class="kv"><b>Age:</b> <?php echo (int)$order['age']; ?></div>
      <div class="kv"><b>Height:</b> <?php echo (int)$order['height']; ?> cm</div>
      <div class="kv"><b>Weight:</b> <?php echo (int)$order['weight']; ?> kg</div>
      <div class="kv"><b>Gender:</b> <?php echo htmlspecialchars($order['gender']); ?></div>
    </div>

    <!-- Main -->
    <div class="card form-card">
      <h2>Edit Program Plan - Order #<?php echo $order_id; ?></h2>
      <?php
      $days = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
      foreach (range(1,4) as $week):
      ?>
        <div class="week-title">Week <?php echo $week; ?></div>
        <div class="table-block">
          <table>
            <?php foreach ($days as $day):
              $abbr = strtolower(substr($day, 0, 3));
              $value = isset($program_data[$week][$day = strtolower($day)]) ? $program_data[$week][$day] : '';
            ?>
              <tr>
                <td style="width: 120px;"><label><?php echo $day; ?></label></td>
                <td>
                  <textarea name="week<?php echo $week; ?>_<?php echo $abbr; ?>"><?php echo htmlspecialchars($value); ?></textarea>
                </td>
              </tr>
            <?php endforeach; ?>
          </table>
        </div>
      <?php endforeach; ?>
      <button class="save" type="submit" name="save_program">Save Program</button>
    </div>
  </div>
</form>

</body>
</html>
