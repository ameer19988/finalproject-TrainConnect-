<?php
include_once 'db_connection.php';
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$con = OpenCon();

$isLoggedIn = isset($_SESSION['logged_in_user']);
$isTrainer = isset($_SESSION['is_trainer']) ? $_SESSION['is_trainer'] : 0;
$username = $isLoggedIn ? $_SESSION['logged_in_user'] : null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title></title>
  <style>
    body {
      margin: 0;
      font-family: Arial, sans-serif;
    }
    .navbar {
      background: #fff;
      box-shadow: 0 2px 8px rgba(0,0,0,0.08);
      position: fixed;
      top: 0; left: 0; right: 0;
      width: 100%;
      z-index: 1000;
    }
    .nav-container {
      max-width: 1100px;
      margin: 0 auto;
      display: flex;
      justify-content: center;
      align-items: center;
      padding: 0 20px;
    }
    .nav-item {
      display: inline-block;
      padding: 18px 20px;
      text-decoration: none;
      color: #333;
      font-weight: 500;
      font-size: 17px;
      transition: color 0.2s;
    }
    .nav-item:hover {
      color: #0066ff;
      background: #f3f6fd;
      border-radius: 8px;
    }
    /* Responsive for mobile */
    @media (max-width: 700px) {
      .nav-container {
        flex-direction: column;
        padding: 0;
      }
      .nav-item {
        width: 100%;
        text-align: center;
        padding: 12px 0;
        font-size: 16px;
      }
    }
    /* Give space for fixed navbar */
    .nav-space { height: 58px; }
  </style>
</head>
<body>
  <div class="navbar">
  <div class="nav-container">
    <a href="index.php" class="nav-item">Home</a>
    <a href="#" class="nav-item">About</a>
    <?php if ($isLoggedIn): ?>
  <a href="my_profile.php" class="nav-item">My Profile</a>
  <?php if ($isTrainer): ?>
    <a href="my_trainer_profile.php" class="nav-item">My Trainer Profile</a>
    <a href="trainer_programs.php" class="nav-item">My Programs</a>
    <a href="trainer_meetings.php" class="nav-item">Today’s Meetings</a>
    <a href="trainer_inbox.php" class="nav-item">Messages</a>
  <?php else: ?>
    <a href="become_trainer.php" class="nav-item">Become a Trainer</a>
    <a href="my_programs.php" class="nav-item">My Program</a>
  <?php endif; ?>
  <a href="logout.php" class="nav-item">Logout (<?php echo htmlspecialchars($username); ?>)</a>
<?php else: ?>
  <a href="login.php" class="nav-item">Sign-in</a>
<?php endif; ?>
  </div>
</div>
<div class="nav-space"></div>
</body>
</html>
