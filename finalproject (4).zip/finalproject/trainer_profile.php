<?php
include 'navbar.php';
include_once 'db_connection.php';
$con = OpenCon();

$trainer_id = (int)($_GET['id'] ?? 0);
if (!$trainer_id) { echo "<div class='info-message'>Trainer not found.</div>"; exit(); }

// Get trainer info
$query = "SELECT * FROM trainers WHERE id = $trainer_id";
$result = mysqli_query($con, $query);
$trainer = mysqli_fetch_assoc($result);
if (!$trainer) { echo "<div class='info-message'>Trainer not found.</div>"; exit(); }

// Get packages
$packages = [];
$pq = "SELECT * FROM packages WHERE trainer_id = $trainer_id";
$pr = mysqli_query($con, $pq);
while($row = mysqli_fetch_assoc($pr)) { $packages[] = $row; }

// Get result photos
$photos = [];
$phq = "SELECT * FROM trainer_results WHERE trainer_id = $trainer_id";
$phr = mysqli_query($con, $phq);
while($row = mysqli_fetch_assoc($phr)) { $photos[] = $row['image']; }

// Simple reviews (one per client per trainer)
$reviews = [];
$rev_q = mysqli_query($con, "SELECT user_id, review_text, created_at FROM reviews WHERE trainer_id = $trainer_id ORDER BY created_at DESC");
while ($rev_q && $r = mysqli_fetch_assoc($rev_q)) {
    $uname = 'User';
    $uid = (int)$r['user_id'];
    $u_q = mysqli_query($con, "SELECT firstname, lastname FROM users WHERE id = $uid");
    if ($u_q && mysqli_num_rows($u_q) > 0) {
        $u = mysqli_fetch_assoc($u_q);
        $uname = trim($u['firstname'].' '.$u['lastname']);
    }
    $reviews[] = [
        'name' => $uname,
        'text' => $r['review_text'],
        'date' => date('d M Y', strtotime($r['created_at'])),
    ];
}
$review_count = count($reviews);

// Star rating display keeps using trainer.rating if present
$rating = isset($trainer['rating']) ? (float)$trainer['rating'] : 0.0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title><?php echo htmlspecialchars($trainer['name']); ?> - Profile</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <style>
:root { --primary:#ff8c3a; --primary-2:#e77a2f; --card-bg:rgba(0,0,0,.55); --soft-bg:rgba(255,255,255,.07); --text:#f5f6f8; --muted:#cfd2d8; --border:rgba(255,255,255,.18); --shadow:0 10px 30px rgba(0,0,0,.35); }
* { box-sizing:border-box; }
body { font-family:Arial,sans-serif; margin:0; padding:0; color:var(--text); background:url('images/back.jpg') center/cover fixed no-repeat; position:relative; min-height:100dvh; }
body::before { content:""; position:fixed; inset:0; background:linear-gradient(180deg,rgba(0,0,0,.45),rgba(0,0,0,.65)); pointer-events:none; }
.product-container { max-width:1200px; margin:24px auto; padding:0 16px 40px; }
.product-main { display:flex; border-radius:16px; background:var(--card-bg); backdrop-filter:blur(8px); -webkit-backdrop-filter:blur(8px); box-shadow:var(--shadow); overflow:hidden; margin-bottom:28px; border:1px solid var(--border); }
.product-gallery { width:40%; padding:26px; border-right:1px solid var(--border); }
.product-info { width:60%; padding:26px; position:relative; }
.main-image { width:100%; height:420px; object-fit:cover; border-radius:12px; box-shadow:0 6px 24px rgba(0,0,0,.35); }
.brand-name { color:var(--muted); font-size:14px; letter-spacing:.3px; margin-bottom:6px; }
.product-title { font-size:30px; font-weight:800; margin:0 0 14px 0; color:#fff; }
.rating { display:flex; align-items:center; gap:10px; margin-bottom:18px; }
.stars { color:#ffd166; font-size:18px; }
.rating-count { color:var(--muted); font-size:14px; }
.price-section { margin-bottom:22px; }
.price { font-size:30px; font-weight:800; color:#ffe08a; }
.best-price { color:#ffe08a; font-size:14px; font-weight:700; display:flex; align-items:center; gap:6px; }
.best-price i { opacity:.95; }
.flavors-section { margin:24px 0; }
.section-heading { font-size:18px; font-weight:800; margin:0 0 14px; color:#fff; }
.flavors-grid { display:grid; grid-template-columns:repeat(auto-fill,minmax(180px,1fr)); gap:12px; }
.flavor-option { background:var(--soft-bg); border:1px solid var(--border); border-radius:12px; padding:12px; text-align:center; transition:transform .18s ease, box-shadow .18s ease, border-color .18s ease, background .18s ease; }
.flavor-option:hover { transform:translateY(-3px); border-color:rgba(255,255,255,.35); box-shadow:0 12px 24px rgba(0,0,0,.25); background:rgba(255,255,255,.12); }
.flavor-name { font-weight:800; color:#fff; margin-bottom:6px; }
.flavor-option div[style*="font-size:12px"] { color:#e6e7ea !important; }
.flavors-section form button { background:var(--primary) !important; border:none !important; color:#fff !important; border-radius:10px !important; padding:10px 16px !important; font-weight:700 !important; cursor:pointer !important; box-shadow:0 6px 16px rgba(0,0,0,.35) !important; transition:transform .15s ease, background .15s ease !important; }
.flavors-section form button:hover { background:var(--primary-2) !important; transform:translateY(-2px) !important; }
.trainer-details { margin-top:22px; display:grid; gap:10px; }
.detail-row { display:flex; gap:10px; }
.detail-label { width:130px; color:var(--muted); }
.detail-value { font-weight:800; color:#fff; }
.results-section, .reviews-section { background:var(--card-bg); backdrop-filter:blur(8px); -webkit-backdrop-filter:blur(8px); border-radius:16px; padding:24px; margin-bottom:28px; border:1px solid var(--border); box-shadow:var(--shadow); }
.results-title { font-size:24px; font-weight:800; margin:0 0 16px; color:#fff; }
.results-grid { display:grid; grid-template-columns:repeat(auto-fill,minmax(240px,1fr)); gap:16px; }
.result-item { height:240px; border-radius:12px; overflow:hidden; border:1px solid var(--border); background:var(--soft-bg); }
.result-item img { width:100%; height:100%; object-fit:cover; transition:transform .25s ease; }
.result-item:hover img { transform:scale(1.06); }
.reviews-header { display:flex; justify-content:space-between; align-items:center; margin-bottom:16px; }
.reviews-title { font-size:22px; font-weight:800; margin:0; color:#fff; }
.average-rating { font-size:28px; font-weight:800; color:#ffe08a; text-align:right; }
.review-count { color:var(--muted); font-size:13px; text-align:right; }
.review-card { border:1px solid var(--border); border-radius:12px; padding:12px; margin-bottom:12px; background:rgba(255,255,255,.06); }
p, .info-message { color:var(--muted); }
@media (max-width:900px) { .product-main{flex-direction:column;} .product-gallery, .product-info{width:100%;} .product-gallery{border-right:none; border-bottom:1px solid var(--border);} .main-image{height:360px;} }
@media (max-width:480px) { .main-image{height:300px;} .product-title{font-size:26px;} }


  </style>
</head>
<body>
<div class="product-container">
  <!-- Main Trainer Section -->
  <div class="product-main">
    <div class="product-gallery">
      <img src="<?php echo htmlspecialchars($trainer['image']); ?>" alt="Trainer Photo" class="main-image">
    </div>

    <div class="product-info">
      <div class="brand-name">Professional Trainer</div>
      <h1 class="product-title"><?php echo htmlspecialchars($trainer['name']); ?></h1>

      <!-- Rating -->
      <div class="rating">
        <div class="stars">
          <?php
          $fullStars = floor($rating);
          $hasHalfStar = ($rating - $fullStars) >= 0.5;
          for ($i = 1; $i <= 5; $i++):
            if ($i <= $fullStars): ?>
              <i class="fas fa-star"></i>
            <?php elseif ($i == $fullStars + 1 && $hasHalfStar): ?>
              <i class="fas fa-star-half-alt"></i>
            <?php else: ?>
              <i class="far fa-star"></i>
            <?php endif;
          endfor; ?>
        </div>
        <span class="rating-count"><?php echo (int)$review_count; ?> reviews</span>
      </div>

      <!-- Price (for packages) -->
      <div class="price-section">
        <?php if (!empty($packages)): ?>
          <div class="price">From <?php echo min(array_column($packages, 'price')); ?>₪</div>
        <?php endif; ?>
        <div class="best-price"><i class="fas fa-check-circle"></i> Best Price Promise</div>
      </div>

      <!-- Packages -->
      <div class="flavors-section">
        <h3 class="section-heading">Training Packages</h3>
        <div class="flavors-grid">
          <?php foreach ($packages as $pkg): ?>
            <div class="flavor-option">
              <div class="flavor-name"><?php echo ucfirst($pkg['type']); ?></div>
              <div><?php echo $pkg['price']; ?>₪</div>
              <?php if ($pkg['type'] == 'regular'): ?>
                <div style="font-size:12px; color:#666; margin:8px 0;">
                  ⏳ 3 days to prepare the program<br>
                  💬 3 days response in chat
                </div>
              <?php else: ?>
                <div style="font-size:12px; color:#666; margin:8px 0;">
                  ⏳ 1 day to prepare the program<br>
                  💬 1 day response in chat
                </div>
              <?php endif; ?>
              <form method="get" action="buy_package.php" style="margin-top:8px;">
                <input type="hidden" name="package_id" value="<?php echo $pkg['id']; ?>">
                <input type="hidden" name="trainer_id" value="<?php echo $trainer_id; ?>">
                <button type="submit" style="padding:8px 16px; background:#0066cc; color:#fff; border:none; border-radius:5px; cursor:pointer;">
                  Buy
                </button>
              </form>
            </div>
          <?php endforeach; ?>
        </div>
      </div>

      <!-- Trainer Details -->
      <div class="trainer-details">
        <div class="detail-row">
          <div class="detail-label">Experience</div>
          <div class="detail-value"><?php echo htmlspecialchars($trainer['experience']); ?> years</div>
        </div>
        <div class="detail-row">
          <div class="detail-label">Specialization</div>
          <div class="detail-value"><?php echo htmlspecialchars($trainer['specialization'] ?? 'General Fitness'); ?></div>
        </div>
        <div class="detail-row">
          <div class="detail-label">Clients</div>
          <div class="detail-value"><?php echo htmlspecialchars($trainer['clients_count'] ?? '50+'); ?></div>
        </div>
      </div>
    </div>
  </div>

  <!-- Results Section -->
  <div class="results-section">
    <h2 class="results-title">Client Transformations</h2>
    <?php if (!empty($photos)): ?>
      <div class="results-grid">
        <?php foreach ($photos as $img): ?>
          <div class="result-item">
            <img src="<?php echo htmlspecialchars($img); ?>" alt="Client Result">
          </div>
        <?php endforeach; ?>
      </div>
    <?php else: ?>
      <p>No transformation photos available yet.</p>
    <?php endif; ?>
  </div>

  <!-- Reviews Section -->
  <div class="reviews-section">
    <div class="reviews-header">
      <h2 class="reviews-title">Customer Reviews</h2>
      <div>
        <div class="average-rating"><?php echo number_format($rating, 1); ?></div>
        <div class="review-count"><?php echo (int)$review_count; ?> reviews</div>
      </div>
    </div>

    <?php if (empty($reviews)): ?>
      <p style="color:#666;">No reviews yet.</p>
    <?php else: ?>
      <?php foreach ($reviews as $rv): ?>
        <div class="review-card">
          <div class="review-meta"><?php echo htmlspecialchars($rv['name']); ?> — <?php echo $rv['date']; ?></div>
          <div style="white-space:pre-wrap;"><?php echo htmlspecialchars($rv['text']); ?></div>
        </div>
      <?php endforeach; ?>
    <?php endif; ?>
  </div>
</div>
</body>
</html>
