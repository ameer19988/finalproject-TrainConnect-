<?php 
include_once 'db_connection.php';
$con = OpenCon();
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <style>
    .grid-container2 {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 20px;
      padding: 5px;
    }

    .grid-container2 > div {
      text-align: center;
      font-size: 20px;
    }

    .item11 img {
      filter: grayscale(100%);
      border-radius: 100%;
      width: 150px;
      height: 150px;
      transition: transform 0.3s, filter 0.3s;
    }

    .item11 img:hover {
      filter: grayscale(0%);
      transform: scale(1.3);
    }
  </style>
</head>
<body>

<div class="grid-container2">
<?php
$query = "SELECT * FROM categories_new";
$result = mysqli_query($con, $query); 

while ($row = mysqli_fetch_assoc($result)) {
  $cat_id = $row['id'];
  $cat_name = $row['name'];
  $cat_image = $row['image'];
  echo "
    <div class='item11'>
      <a href='trainers.php?category_id=$cat_id'>
        <img src='$cat_image' alt='$cat_name' />
      </a>
      <br><br>$cat_name
    </div>
  ";
}
?>
</div>

</body>
</html>




