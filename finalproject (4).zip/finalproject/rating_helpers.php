<?php

function recalc_trainer_rating(mysqli $con, int $trainer_id): void
{
    // 1) pull totals
    $q = mysqli_query($con, "
        SELECT
          (SELECT COUNT(*) FROM trainer_orders WHERE trainer_id = $trainer_id)                  AS total_orders,
          (SELECT COUNT(*) FROM trainer_orders WHERE trainer_id = $trainer_id AND is_completed=1) AS completed_orders,
          (SELECT delay_points FROM trainers WHERE id = $trainer_id)                           AS delay_points
    ");
    if (!$q) return;
    $row = mysqli_fetch_assoc($q);
    $total_orders     = (int)$row['total_orders'];
    $completed_orders = (int)$row['completed_orders'];
    $delay_points     = (int)$row['delay_points'];

    // 2) ratios (no orders => 0, not 1)
    $completionRatio = ($total_orders > 0) ? ($completed_orders / max(1, $total_orders)) : 0.0; // 0..1

    // 3) timeliness: each delay point = -0.5 stars, floor at 0
    $timeliness = max(0.0, 5.0 - 0.5 * $delay_points); // 0..5

    // 4) final score (0..5), rounded to one decimal
    $rating = (0.70 * ($completionRatio * 5.0)) + (0.30 * $timeliness);
    $rating = round($rating, 1);

    // 5) save
    mysqli_query($con, "UPDATE trainers SET rating = $rating WHERE id = $trainer_id");
}
