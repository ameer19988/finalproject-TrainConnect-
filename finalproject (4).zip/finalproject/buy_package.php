<?php
include 'navbar.php';
include_once 'db_connection.php';
$con = OpenCon();

if (!isset($_SESSION['logged_in_user'])) {
    header("Location: login.php");
    exit();
}

$package_id = isset($_GET['package_id']) ? (int)$_GET['package_id'] : 0;
$trainer_id = isset($_GET['trainer_id']) ? (int)$_GET['trainer_id'] : 0;

if (!$package_id || !$trainer_id) {
    echo "<div class='info-message'>Invalid request.</div>";
    exit();
}

// Get package info by ID
$pkg_q = mysqli_query($con, "SELECT * FROM packages WHERE id = $package_id AND trainer_id = $trainer_id");
$package = mysqli_fetch_assoc($pkg_q);
if (!$package) {
    echo "<div class='info-message'>Package not found.</div>";
    exit();
}
$package_type = $package['type'];

// Get trainer info
$res = mysqli_query($con, "SELECT * FROM trainers WHERE id = $trainer_id");
$trainer = mysqli_fetch_assoc($res);
if (!$trainer) {
    echo "<div class='info-message'>Trainer not found.</div>";
    exit();
}

$dayArr = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday'];
$hourArr = ["10:00", "11:00", "12:00", "13:00", "14:00", "15:00", "16:00", "17:00", "18:00", "19:00"];

// 1. If program ordered, handle submission
if (isset($_POST['orderProgram'])) {
    $user = $_SESSION['logged_in_user'];
    $res_user = mysqli_query($con, "SELECT id FROM users WHERE username = '$user'");
    $userRow = mysqli_fetch_assoc($res_user);
    $user_id = $userRow['id'];

    $height = $_POST['height'];
    $weight = $_POST['weight'];
    $age = $_POST['age'];
    $gender = $_POST['gender'];
    $notes = mysqli_real_escape_string($con, $_POST['notes']);
    $meeting_day = $_POST['meeting_day'];
    $meeting_time = $_POST['meeting_time'];
    $photoPath = "";

    // --- Photo upload logic ---
    if (isset($_FILES['photo']) && $_FILES['photo']['error'] === 0) {
        $imageName = $_FILES['photo']['name'];
        $imageTmpName = $_FILES['photo']['tmp_name'];
        $imageFolder = 'images/' . $imageName;
        if (move_uploaded_file($imageTmpName, $imageFolder)) {
            $photoPath = $imageFolder;
        } else {
            echo "<div class='info-message'>Failed to upload your photo.</div>";
        }
    }

    // Check if the slot is already booked 
    $slot_check = mysqli_query($con, "SELECT COUNT(*) AS cnt FROM trainer_orders WHERE trainer_id=$trainer_id AND meeting_day='$meeting_day' AND meeting_time='$meeting_time'");
    $slot_row = mysqli_fetch_assoc($slot_check);
    if ($slot_row['cnt'] > 0) {
        echo '<div class="info-message" style="color:red;">Sorry, this time is already booked. Please try another.</div>';
    } else {
        // Insert order into trainer_orders
        $insert_q = "INSERT INTO trainer_orders (user_id, trainer_id, package_type, height, weight, age, gender, notes, photo, meeting_day, meeting_time) 
            VALUES ('$user_id', '$trainer_id', '$package_type', '$height', '$weight', '$age', '$gender', '$notes', '$photoPath', '$meeting_day', '$meeting_time')";
        $done = mysqli_query($con, $insert_q);

        if ($done) {
            echo '<div class="info-message" style="color:green;">Your request was sent! The trainer will prepare your program soon.<br>
                <small>You will move to the homepage in a moment...</small>
                </div>
                <script>
                setTimeout(function(){ window.location.href="index.php"; }, 3500);
                </script>';
            exit();
        } else {
            echo "<div class='info-message' style='color:red;'>Failed to send your request. Try again later.</div>";
        }
    }
}

// 2. Get state of form steps
$meeting_day = isset($_POST['meeting_day']) ? $_POST['meeting_day'] : '';
$step = $meeting_day ? 2 : 1;
$available_times = [];

if ($step == 2) {
    // Get available slots for this day
    $taken = [];
    $q = mysqli_query($con, "SELECT meeting_time FROM trainer_orders WHERE trainer_id=$trainer_id AND meeting_day='$meeting_day'");
    while ($row = mysqli_fetch_assoc($q)) {
        $taken[] = $row['meeting_time'];
    }
    foreach ($hourArr as $t) {
        if (!in_array($t, $taken)) {
            $available_times[] = $t;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Order Program from <?php echo htmlspecialchars($trainer['name']); ?></title>
<style>
body { font-family: Arial, sans-serif; margin: 0; background: url('images/back.jpg') center/cover fixed no-repeat; color: #f5f6f8; }

.order-container { max-width: 460px; margin: 42px auto; background: rgba(0,0,0,.55); backdrop-filter: blur(8px); -webkit-backdrop-filter: blur(8px); border-radius: 14px; box-shadow: 0 10px 30px rgba(0,0,0,.35); padding: 28px; border: 1px solid rgba(255,255,255,.18); }

h2 { margin: 0 0 12px; color: #ffe08a; text-align: center; }

.info-message { text-align: center; color: #ffd08a; background: rgba(255,255,255,.08); border: 1px solid rgba(255,255,255,.25); border-radius: 10px; padding: 11px; margin-bottom: 20px; }

.form-label { display: block; margin: 0 0 7px; color: #e8e9ec; font-size: 1em; }

.form-input, .form-select, .form-textarea { width: 100%; padding: 10px 12px; margin: 0 0 14px; border-radius: 10px; border: 1px solid rgba(255,255,255,.22); font-size: 1em; background: rgba(255,255,255,.08); color: #fff; transition: border .2s, background .2s; box-sizing: border-box; }

.form-input:focus, .form-select:focus, .form-textarea:focus { border: 1px solid #ff8c3a; background: rgba(255,255,255,.14); outline: none; }

.form-input::placeholder, .form-textarea::placeholder { color: #cfd2d8; }

.form-textarea { min-height: 60px; resize: vertical; }

.submit-btn { width: 100%; background: #ff8c3a; color: #fff; border: none; border-radius: 30px; padding: 12px 0; font-size: 1.08em; font-weight: 700; cursor: pointer; margin-top: 8px; box-shadow: 0 8px 20px rgba(0,0,0,.35); transition: transform .15s ease, background .15s ease; }

.submit-btn:hover { background: #e77a2f; transform: translateY(-2px); }

.note { background: rgba(255,255,255,.08); padding: 8px 12px; margin: 0 0 14px; border-radius: 10px; font-size: .96em; color: #e6e7ea; border: 1px solid rgba(255,255,255,.18); }

.package-title { color: #ffe08a; font-weight: 800; }

select.form-select, option { color: #000; }

@media (max-width: 520px) { .order-container { margin: 24px 12px; padding: 20px; } }

</style>
</head>
<body>
<div class="order-container">
  <h2>Order Program from <br><?php echo htmlspecialchars($trainer['name']); ?></h2>
  <div class="note">
    <span class="package-title"><?php echo ucfirst($package_type); ?> Package</span> -
    <?php
      if ($package_type == 'regular') {
        echo "Program ready in <b>3 days</b> · Replies in chat within <b>3 days</b>";
      } else {
        echo "Program ready in <b>1 day</b> · Replies in chat within <b>1 day</b>";
      }
    ?>
  </div>

  <?php if ($step == 1): ?>
    <!-- Step 1: Choose day -->
    <form method="POST">
      <label class="form-label">Preferred weekly video call day:</label>
      <select class="form-select" name="meeting_day" required onchange="this.form.submit()">
        <option value="">Select a day...</option>
        <?php foreach ($dayArr as $d): ?>
          <option value="<?php echo $d; ?>"><?php echo $d; ?></option>
        <?php endforeach; ?>
      </select>
    </form>
  <?php elseif ($step == 2): ?>
    <!-- Step 2: Choose hour + fill form -->
    <form method="POST" enctype="multipart/form-data">
      <input type="hidden" name="meeting_day" value="<?php echo htmlspecialchars($meeting_day); ?>">
      <label class="form-label">Preferred time (1 hour, 10:00-19:00):</label>
      <select class="form-select" name="meeting_time" required>
        <option value="">Select time...</option>
        <?php foreach ($available_times as $t): ?>
          <option value="<?php echo $t; ?>"><?php echo $t . " - " . (intval($t)+1) . ":00"; ?></option>
        <?php endforeach; ?>
      </select>
      <label class="form-label">Height (cm):</label>
      <input class="form-input" type="number" name="height" min="120" max="250" required>
      <label class="form-label">Weight (kg):</label>
      <input class="form-input" type="number" name="weight" min="30" max="200" required>
      <label class="form-label">Age:</label>
      <input class="form-input" type="number" name="age" min="10" max="99" required>
      <label class="form-label">Gender:</label>
      <select class="form-select" name="gender" required>
        <option value="">Select gender...</option>
        <option value="Male">Male</option>
        <option value="Female">Female</option>
      </select>
      <label class="form-label">Upload a photo (optional):</label>
      <input class="form-input" type="file" name="photo" accept="image/*">
      <label class="form-label">Anything the trainer should know? (notes)</label>
      <textarea class="form-textarea" name="notes" placeholder="Write any comments, goals, preferences, or limitations..."></textarea>
      <button class="submit-btn" name="orderProgram">Send Request</button>
    </form>
  <?php endif; ?>
</div>
</body>
</html>
